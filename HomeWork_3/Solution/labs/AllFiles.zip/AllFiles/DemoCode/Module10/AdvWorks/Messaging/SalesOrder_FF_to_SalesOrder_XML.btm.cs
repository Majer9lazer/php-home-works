namespace AdvWorks.Messaging {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.Messaging.SalesOrder_FF", typeof(global::AdvWorks.Messaging.SalesOrder_FF))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.Messaging.SalesOrder", typeof(global::AdvWorks.Messaging.SalesOrder))]
    public sealed class SalesOrder_FF_to_SalesOrder_XML : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp ScriptNS0"" version=""1.0"" xmlns:ns0=""http://AdvWorks.Messaging.SalesOrderv1.0"" xmlns:s0=""http://AdvWorks.Messaging.SalesOrderFFv1.0"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:SalesOrder"" />
  </xsl:template>
  <xsl:template match=""/s0:SalesOrder"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringUpperCase(string(OrderDetail/@Cash_Cred))"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:DateCurrentDate()"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:StringUpperCase(string(CustomerInfo/@ID))"" />
    <xsl:variable name=""var:v4"" select=""string(CustomerInfo/@ID)"" />
    <xsl:variable name=""var:v5"" select=""userCSharp:StringUpperCase($var:v4)"" />
    <xsl:variable name=""var:v21"" select=""userCSharp:StringConcat(&quot;6&quot;)"" />
    <ns0:SalesOrder>
      <Detail>
        <xsl:if test=""OrderDetail/@StoreNumber"">
          <xsl:attribute name=""StoreNumber"">
            <xsl:value-of select=""OrderDetail/@StoreNumber"" />
          </xsl:attribute>
        </xsl:if>
        <xsl:if test=""OrderDetail/@Employee"">
          <xsl:attribute name=""Employee"">
            <xsl:value-of select=""OrderDetail/@Employee"" />
          </xsl:attribute>
        </xsl:if>
        <xsl:if test=""OrderDetail/@OrderNumber"">
          <xsl:attribute name=""OrderNumber"">
            <xsl:value-of select=""OrderDetail/@OrderNumber"" />
          </xsl:attribute>
        </xsl:if>
        <xsl:attribute name=""OrderType"">
          <xsl:value-of select=""$var:v1"" />
        </xsl:attribute>
        <xsl:attribute name=""OrderDate"">
          <xsl:value-of select=""$var:v2"" />
        </xsl:attribute>
      </Detail>
      <CustomerInfo>
        <xsl:attribute name=""ID"">
          <xsl:value-of select=""$var:v3"" />
        </xsl:attribute>
        <xsl:if test=""CustomerInfo/@CustomerName"">
          <xsl:attribute name=""CustomerName"">
            <xsl:value-of select=""CustomerInfo/@CustomerName"" />
          </xsl:attribute>
        </xsl:if>
        <xsl:if test=""CustomerInfo/@MonthsAtResidence"">
          <xsl:attribute name=""MonthsAtResidence"">
            <xsl:value-of select=""CustomerInfo/@MonthsAtResidence"" />
          </xsl:attribute>
        </xsl:if>
        <Residence>
          <Street>
            <xsl:value-of select=""CustomerInfo/Address/text()"" />
          </Street>
          <City>
            <xsl:value-of select=""CustomerInfo/Town/text()"" />
          </City>
          <State>
            <xsl:value-of select=""CustomerInfo/Region/text()"" />
          </State>
          <PostalCode>
            <xsl:value-of select=""CustomerInfo/ZipCode/text()"" />
          </PostalCode>
        </Residence>
        <BillingAddress>
          <xsl:variable name=""var:v6"" select=""ScriptNS0:DBLookup(0 , string($var:v5) , &quot;Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;User ID=Administrator;Initial Catalog=advworks;Data Source=BizTalkDemo&quot; , &quot;CUSTOMER&quot; , &quot;CUSTID&quot;)"" />
          <xsl:variable name=""var:v7"" select=""ScriptNS0:DBValueExtract(string($var:v6) , &quot;ADDRESS&quot;)"" />
          <Street>
            <xsl:value-of select=""$var:v7"" />
          </Street>
          <xsl:variable name=""var:v8"" select=""ScriptNS0:DBLookup(0 , string($var:v5) , &quot;Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;User ID=Administrator;Initial Catalog=advworks;Data Source=BizTalkDemo&quot; , &quot;CUSTOMER&quot; , &quot;CUSTID&quot;)"" />
          <xsl:variable name=""var:v9"" select=""ScriptNS0:DBValueExtract(string($var:v8) , &quot;CITY&quot;)"" />
          <City>
            <xsl:value-of select=""$var:v9"" />
          </City>
          <xsl:variable name=""var:v10"" select=""ScriptNS0:DBLookup(0 , string($var:v5) , &quot;Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;User ID=Administrator;Initial Catalog=advworks;Data Source=BizTalkDemo&quot; , &quot;CUSTOMER&quot; , &quot;CUSTID&quot;)"" />
          <xsl:variable name=""var:v11"" select=""ScriptNS0:DBValueExtract(string($var:v10) , &quot;STATE&quot;)"" />
          <State>
            <xsl:value-of select=""$var:v11"" />
          </State>
          <xsl:variable name=""var:v12"" select=""ScriptNS0:DBLookup(0 , string($var:v5) , &quot;Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;User ID=Administrator;Initial Catalog=advworks;Data Source=BizTalkDemo&quot; , &quot;CUSTOMER&quot; , &quot;CUSTID&quot;)"" />
          <xsl:variable name=""var:v13"" select=""ScriptNS0:DBValueExtract(string($var:v12) , &quot;ZIP&quot;)"" />
          <PostalCode>
            <xsl:value-of select=""$var:v13"" />
          </PostalCode>
        </BillingAddress>
        <Income>
          <xsl:if test=""OrderDetail/CreditInfo/@Employer"">
            <xsl:attribute name=""Employer"">
              <xsl:value-of select=""OrderDetail/CreditInfo/@Employer"" />
            </xsl:attribute>
          </xsl:if>
          <xsl:if test=""OrderDetail/CreditInfo/@MonthsEmployed"">
            <xsl:attribute name=""MonthsEmployed"">
              <xsl:value-of select=""OrderDetail/CreditInfo/@MonthsEmployed"" />
            </xsl:attribute>
          </xsl:if>
          <MonthlyIncome>
            <xsl:if test=""OrderDetail/CreditInfo/@PrimaryIncome"">
              <xsl:attribute name=""Primary"">
                <xsl:value-of select=""OrderDetail/CreditInfo/@PrimaryIncome"" />
              </xsl:attribute>
            </xsl:if>
            <xsl:if test=""OrderDetail/CreditInfo/@OtherIncome"">
              <xsl:attribute name=""Other"">
                <xsl:value-of select=""OrderDetail/CreditInfo/@OtherIncome"" />
              </xsl:attribute>
            </xsl:if>
          </MonthlyIncome>
        </Income>
      </CustomerInfo>
      <Items>
        <xsl:for-each select=""Products/Product"">
          <xsl:variable name=""var:v14"" select=""userCSharp:MathMultiply(string(@Quantity) , string(@PriceEach))"" />
          <Item>
            <xsl:if test=""@Quantity"">
              <xsl:attribute name=""Qty"">
                <xsl:value-of select=""@Quantity"" />
              </xsl:attribute>
            </xsl:if>
            <xsl:if test=""@ItemNumber"">
              <xsl:attribute name=""SKU"">
                <xsl:value-of select=""@ItemNumber"" />
              </xsl:attribute>
            </xsl:if>
            <xsl:if test=""@PriceEach"">
              <xsl:attribute name=""Price"">
                <xsl:value-of select=""@PriceEach"" />
              </xsl:attribute>
            </xsl:if>
            <xsl:attribute name=""ExtendedPrice"">
              <xsl:value-of select=""$var:v14"" />
            </xsl:attribute>
          </Item>
        </xsl:for-each>
      </Items>
      <Comment>
        <xsl:value-of select=""Comment/text()"" />
      </Comment>
      <xsl:variable name=""var:v15"" select=""userCSharp:InitCumulativeSum(0)"" />
      <xsl:for-each select=""/s0:SalesOrder/Products/Product"">
        <xsl:variable name=""var:v16"" select=""string(@Quantity)"" />
        <xsl:variable name=""var:v17"" select=""string(@PriceEach)"" />
        <xsl:variable name=""var:v18"" select=""userCSharp:MathMultiply($var:v16 , $var:v17)"" />
        <xsl:variable name=""var:v19"" select=""userCSharp:AddToCumulativeSum(0,string($var:v18),&quot;1000&quot;)"" />
      </xsl:for-each>
      <xsl:variable name=""var:v20"" select=""userCSharp:GetCumulativeSum(0)"" />
      <OrderTotal>
        <xsl:value-of select=""$var:v20"" />
      </OrderTotal>
      <TermOfLoan>
        <xsl:value-of select=""$var:v21"" />
      </TermOfLoan>
    </ns0:SalesOrder>
    <xsl:variable name=""var:v22"" select=""ScriptNS0:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringUpperCase(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.ToUpper(System.Globalization.CultureInfo.InvariantCulture);
}


public string MathMultiply(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 1;
	bool first = true;
	foreach (string obj in listValues)
	{
		double d = 0;
		if (IsNumeric(obj, ref d))
		{
			if (first)
			{
				first = false;
				ret = d;
			}
			else
			{
				ret *= d;
			}
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public string InitCumulativeSum(int index)
{
	if (index >= 0)
	{
		if (index >= myCumulativeSumArray.Count)
		{
			int i = myCumulativeSumArray.Count;
			for (; i<=index; i++)
			{
				myCumulativeSumArray.Add("""");
			}
		}
		else
		{
			myCumulativeSumArray[index] = """";
		}
	}
	return """";
}

public System.Collections.ArrayList myCumulativeSumArray = new System.Collections.ArrayList();

public string AddToCumulativeSum(int index, string val, string notused)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
    }
	double d = 0;
	if (IsNumeric(val, ref d))
	{
		if (myCumulativeSumArray[index] == """")
		{
			myCumulativeSumArray[index] = d;
		}
		else
		{
			myCumulativeSumArray[index] = (double)(myCumulativeSumArray[index]) + d;
		}
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string GetCumulativeSum(int index)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string DateCurrentDate()
{
	DateTime dt = DateTime.Now;
	return dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
}


public string StringConcat(string param0)
{
   return param0;
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"AdvWorks.Messaging.SalesOrder_FF";
        
        private const global::AdvWorks.Messaging.SalesOrder_FF _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"AdvWorks.Messaging.SalesOrder";
        
        private const global::AdvWorks.Messaging.SalesOrder _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"AdvWorks.Messaging.SalesOrder_FF";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"AdvWorks.Messaging.SalesOrder";
                return _TrgSchemas;
            }
        }
    }
}
