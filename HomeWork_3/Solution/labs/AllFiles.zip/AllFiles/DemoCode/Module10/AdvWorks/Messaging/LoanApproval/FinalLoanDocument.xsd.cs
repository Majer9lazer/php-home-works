namespace AdvWorks.LoanApproval {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://AdvWorks.Processes.ManualApprovalProcessing",@"FinalLoan")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::AdvWorks.LoanApproval.PropertySchema.Customer), XPath = @"/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='CustomerName' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::AdvWorks.LoanApproval.PropertySchema.Amount), XPath = @"/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='Amount' and namespace-uri()='']", XsdType = @"decimal")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "Loan.Status", XPath = @"/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='Status' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.Decimal), "Loan.Amount", XPath = @"/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='Amount' and namespace-uri()='']", XsdType = @"decimal")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.Decimal), "Loan.Term", XPath = @"/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='Term' and namespace-uri()='']", XsdType = @"decimal")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.Decimal), "Loan.LoanToIncomeRatio", XPath = @"/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='LoanToIncomeRatio' and namespace-uri()='']", XsdType = @"decimal")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"FinalLoan"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.LoanApproval.PropertySchema.ps_correlation", typeof(global::AdvWorks.LoanApproval.PropertySchema.ps_correlation))]
    public sealed class FinalLoanDocument : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://AdvWorks.Processes.ManualApprovalProcessing"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns0=""http://AdvWorks.LoanApproval.Messages.PS_Correlation"" targetNamespace=""http://AdvWorks.Processes.ManualApprovalProcessing"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""http://AdvWorks.LoanApproval.Messages.PS_Correlation"" location=""AdvWorks.LoanApproval.PropertySchema.ps_correlation"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""FinalLoan"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""ns0:Customer"" xpath=""/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='CustomerName' and namespace-uri()='']"" />
          <b:property name=""ns0:Amount"" xpath=""/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='Amount' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='Status' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='Amount' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='Term' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='FinalLoan' and namespace-uri()='http://AdvWorks.Processes.ManualApprovalProcessing']/*[local-name()='Loan' and namespace-uri()='']/*[local-name()='LoanToIncomeRatio' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CustomerName"" type=""xs:string"" />
        <xs:element name=""Address"">
          <xs:complexType>
            <xs:attribute name=""Street"" type=""xs:string"" />
            <xs:attribute name=""City"" type=""xs:string"" />
            <xs:attribute name=""State"" type=""xs:string"" />
            <xs:attribute name=""Zip"" type=""xs:string"" />
            <xs:attribute name=""TimeAtResidence"" type=""xs:string"" />
          </xs:complexType>
        </xs:element>
        <xs:element name=""Employment"">
          <xs:complexType>
            <xs:attribute name=""Employer"" type=""xs:string"" />
            <xs:attribute name=""TimeAtEmployer"" type=""xs:string"" />
          </xs:complexType>
        </xs:element>
        <xs:element name=""PrimaryIncome"" type=""xs:string"" />
        <xs:element name=""OtherIncome"" type=""xs:string"" />
        <xs:element name=""Loan"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""Status"" type=""xs:string"" />
              <xs:element name=""Amount"" type=""xs:decimal"" />
              <xs:element name=""Term"" type=""xs:decimal"" />
              <xs:element name=""LoanToIncomeRatio"" type=""xs:decimal"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public FinalLoanDocument() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "FinalLoan";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
