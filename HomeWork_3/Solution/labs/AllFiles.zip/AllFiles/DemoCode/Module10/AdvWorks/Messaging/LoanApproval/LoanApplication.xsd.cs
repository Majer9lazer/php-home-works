namespace AdvWorks.LoanApproval {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://LoansProcessor.LoanApp",@"LoanApp")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "LoanConditions.LoanStatus", XPath = @"/*[local-name()='LoanApp' and namespace-uri()='http://LoansProcessor.LoanApp']/*[local-name()='LoanConditions' and namespace-uri()='']/@*[local-name()='LoanStatus' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.Decimal), "LoanConditions.LoanAmount", XPath = @"/*[local-name()='LoanApp' and namespace-uri()='http://LoansProcessor.LoanApp']/*[local-name()='LoanConditions' and namespace-uri()='']/@*[local-name()='LoanAmount' and namespace-uri()='']", XsdType = @"decimal")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.Decimal), "LoanConditions.Term", XPath = @"/*[local-name()='LoanApp' and namespace-uri()='http://LoansProcessor.LoanApp']/*[local-name()='LoanConditions' and namespace-uri()='']/@*[local-name()='Term' and namespace-uri()='']", XsdType = @"decimal")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.Decimal), "LoanConditions.LoanToIncome", XPath = @"/*[local-name()='LoanApp' and namespace-uri()='http://LoansProcessor.LoanApp']/*[local-name()='LoanConditions' and namespace-uri()='']/@*[local-name()='LoanToIncome' and namespace-uri()='']", XsdType = @"decimal")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"LoanApp"})]
    public sealed class LoanApplication : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://LoansProcessor.LoanApp"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://LoansProcessor.LoanApp"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""LoanApp"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property distinguished=""true"" xpath=""/*[local-name()='LoanApp' and namespace-uri()='http://LoansProcessor.LoanApp']/*[local-name()='LoanConditions' and namespace-uri()='']/@*[local-name()='LoanStatus' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='LoanApp' and namespace-uri()='http://LoansProcessor.LoanApp']/*[local-name()='LoanConditions' and namespace-uri()='']/@*[local-name()='LoanAmount' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='LoanApp' and namespace-uri()='http://LoansProcessor.LoanApp']/*[local-name()='LoanConditions' and namespace-uri()='']/@*[local-name()='Term' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='LoanApp' and namespace-uri()='http://LoansProcessor.LoanApp']/*[local-name()='LoanConditions' and namespace-uri()='']/@*[local-name()='LoanToIncome' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""LoanConditions"">
          <xs:complexType>
            <xs:attribute name=""LoanStatus"" type=""xs:string"" />
            <xs:attribute name=""LoanAmount"" type=""xs:decimal"" />
            <xs:attribute name=""Term"" type=""xs:decimal"" />
            <xs:attribute name=""LoanToIncome"" type=""xs:decimal"" />
          </xs:complexType>
        </xs:element>
        <xs:element name=""Income"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""BasicSalary"" type=""xs:decimal"" />
              <xs:element name=""OtherIncome"" type=""xs:decimal"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""Employment"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""TimeInMonths"" type=""xs:integer"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""Residency"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""TimeInMonths"" type=""xs:integer"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public LoanApplication() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "LoanApp";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
