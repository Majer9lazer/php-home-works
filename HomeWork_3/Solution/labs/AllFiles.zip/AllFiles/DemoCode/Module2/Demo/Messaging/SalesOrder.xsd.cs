namespace Demo.Messaging {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Demo.Messaging.SalesOrderv1.0",@"SalesOrder")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Demo.Messaging.OrderType), XPath = @"/*[local-name()='SalesOrder' and namespace-uri()='http://Demo.Messaging.SalesOrderv1.0']/*[local-name()='Detail' and namespace-uri()='']/@*[local-name()='OrderType' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"SalesOrder"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demo.Messaging.PropertySchema", typeof(global::Demo.Messaging.PropertySchema))]
    public sealed class SalesOrder : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Demo.Messaging.SalesOrderv1.0"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns0=""https://Messaging.PropertySchema"" targetNamespace=""http://Demo.Messaging.SalesOrderv1.0"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""https://Messaging.PropertySchema"" location=""Demo.Messaging.PropertySchema"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""SalesOrder"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""ns0:OrderType"" xpath=""/*[local-name()='SalesOrder' and namespace-uri()='http://Demo.Messaging.SalesOrderv1.0']/*[local-name()='Detail' and namespace-uri()='']/@*[local-name()='OrderType' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""Detail"">
          <xs:complexType>
            <xs:attribute name=""StoreNumber"" type=""xs:string"" />
            <xs:attribute name=""Employee"" type=""xs:string"" />
            <xs:attribute name=""OrderNumber"" type=""xs:string"" />
            <xs:attribute name=""OrderType"">
              <xs:simpleType>
                <xs:restriction base=""xs:string"">
                  <xs:enumeration value=""CASH"" />
                  <xs:enumeration value=""CRED"" />
                  <xs:enumeration value=""Cash"" />
                  <xs:enumeration value=""Credit"" />
                </xs:restriction>
              </xs:simpleType>
            </xs:attribute>
            <xs:attribute name=""OrderDate"" type=""xs:date"" />
          </xs:complexType>
        </xs:element>
        <xs:element name=""CustomerInfo"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""Residence"" type=""Address"" />
              <xs:element name=""BillingAddress"" type=""Address"" />
              <xs:element minOccurs=""0"" name=""Income"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element maxOccurs=""unbounded"" name=""MonthlyIncome"">
                      <xs:complexType>
                        <xs:attribute name=""Primary"" type=""xs:string"" />
                        <xs:attribute name=""Other"" type=""xs:string"" />
                      </xs:complexType>
                    </xs:element>
                  </xs:sequence>
                  <xs:attribute name=""Employer"" type=""xs:string"" />
                  <xs:attribute name=""MonthsEmployed"" type=""xs:string"" />
                </xs:complexType>
              </xs:element>
            </xs:sequence>
            <xs:attribute name=""ID"" type=""xs:string"" />
            <xs:attribute name=""CustomerName"" type=""xs:string"" />
            <xs:attribute name=""MonthsAtResidence"" type=""xs:string"" />
          </xs:complexType>
        </xs:element>
        <xs:element name=""Items"">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs=""unbounded"" name=""Item"">
                <xs:complexType>
                  <xs:attribute name=""Qty"" type=""xs:nonNegativeInteger"" />
                  <xs:attribute name=""SKU"" type=""xs:string"" />
                  <xs:attribute name=""Price"" type=""xs:decimal"" />
                  <xs:attribute name=""ExtendedPrice"" type=""xs:decimal"" />
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""Comment"" type=""xs:string"" />
        <xs:element name=""OrderTotal"" type=""xs:string"" />
        <xs:element name=""TermOfLoan"" type=""xs:string"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:complexType name=""Address"">
    <xs:sequence>
      <xs:element name=""Street"" type=""xs:string"" />
      <xs:element name=""City"" type=""xs:string"" />
      <xs:element name=""State"" type=""xs:string"" />
      <xs:element name=""PostalCode"" type=""xs:string"" />
    </xs:sequence>
  </xs:complexType>
</xs:schema>";
        
        public SalesOrder() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "SalesOrder";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
