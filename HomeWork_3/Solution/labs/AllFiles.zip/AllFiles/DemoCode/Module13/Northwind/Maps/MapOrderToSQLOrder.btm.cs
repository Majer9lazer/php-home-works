namespace Demos.Northwind.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.OrderInternal", typeof(global::Demos.Northwind.Schemas.OrderInternal))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.OrderProcessingTypedProcedure_dbo+AddOrder", typeof(global::Demos.Northwind.Schemas.OrderProcessingTypedProcedure_dbo.AddOrder))]
    public sealed class MapOrderToSQLOrder : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s1 s0 userCSharp"" version=""1.0"" xmlns:ns0=""http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/dbo"" xmlns:s1=""http://demos.northwind.com/fbts/order/internal"" xmlns:s0=""http://demos.northwind.com/fbts/common"" xmlns:ns3=""http://schemas.microsoft.com/Sql/2008/05/Types/TableTypes/dbo"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s1:Order"" />
  </xsl:template>
  <xsl:template match=""/s1:Order"">
    <xsl:variable name=""var:v1"" select=""userCSharp:DateAddDays(string(OrderDate/text()) , &quot;5&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringConcat(string(s0:ShipTo/Line1/text()) , &quot; &quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:StringConcat(&quot;USA&quot;)"" />
    <ns0:AddOrder>
      <ns0:customerID>
        <xsl:value-of select=""CustomerID/text()"" />
      </ns0:customerID>
      <ns0:OrderDate>
        <xsl:value-of select=""OrderDate/text()"" />
      </ns0:OrderDate>
      <ns0:RequiredDate>
        <xsl:value-of select=""$var:v1"" />
      </ns0:RequiredDate>
      <ns0:ShipName>
        <xsl:value-of select=""s0:ShipTo/Addressee/text()"" />
      </ns0:ShipName>
      <ns0:ShipAddress>
        <xsl:value-of select=""$var:v2"" />
      </ns0:ShipAddress>
      <ns0:ShipCity>
        <xsl:value-of select=""s0:ShipTo/City/text()"" />
      </ns0:ShipCity>
      <ns0:ShipRegion>
        <xsl:value-of select=""s0:ShipTo/Region/text()"" />
      </ns0:ShipRegion>
      <ns0:ShipPostalCode>
        <xsl:value-of select=""s0:ShipTo/PostalCode/text()"" />
      </ns0:ShipPostalCode>
      <ns0:ShipCountry>
        <xsl:value-of select=""$var:v3"" />
      </ns0:ShipCountry>
      <ns0:Details>
        <xsl:for-each select=""LineItems/s0:LineItem"">
          <ns3:OrderDetailTableType>
            <ns3:ProductID>
              <xsl:value-of select=""ProductID/text()"" />
            </ns3:ProductID>
            <ns3:UnitPrice>
              <xsl:value-of select=""UnitPrice/text()"" />
            </ns3:UnitPrice>
            <ns3:Quantity>
              <xsl:value-of select=""Quantity/text()"" />
            </ns3:Quantity>
          </ns3:OrderDetailTableType>
        </xsl:for-each>
      </ns0:Details>
    </ns0:AddOrder>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string DateAddDays(string date, string days)
{
	string retval = """";
	double db = 0;
	if (IsDate(date) && IsNumeric(days, ref db))
	{
		DateTime dt = DateTime.Parse(date);
		int d = (int) db;
		dt = dt.AddDays(d);
		retval = dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
	}
	return retval;
}


public string StringConcat(string param0, string param1)
{
   return param0 + param1;
}


public string StringConcat(string param0)
{
   return param0;
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsDate(string val)
{
	bool retval = true;
	try
	{
		DateTime dt = Convert.ToDateTime(val, System.Globalization.CultureInfo.InvariantCulture);
	}
	catch (Exception)
	{
		retval = false;
	}
	return retval;
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Demos.Northwind.Schemas.OrderInternal";
        
        private const global::Demos.Northwind.Schemas.OrderInternal _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Demos.Northwind.Schemas.OrderProcessingTypedProcedure_dbo+AddOrder";
        
        private const global::Demos.Northwind.Schemas.OrderProcessingTypedProcedure_dbo.AddOrder _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Demos.Northwind.Schemas.OrderInternal";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Demos.Northwind.Schemas.OrderProcessingTypedProcedure_dbo+AddOrder";
                return _TrgSchemas;
            }
        }
    }
}
