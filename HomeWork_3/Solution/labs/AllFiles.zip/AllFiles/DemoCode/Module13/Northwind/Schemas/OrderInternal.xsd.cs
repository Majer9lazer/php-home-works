namespace Demos.Northwind.Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://demos.northwind.com/fbts/order/internal",@"Order")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Demos.Northwind.Schemas.Customer), XPath = @"/*[local-name()='Order' and namespace-uri()='http://demos.northwind.com/fbts/order/internal']/*[local-name()='CustomerID' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::Demos.Northwind.Schemas.ShipToCountry), XPath = @"/*[local-name()='Order' and namespace-uri()='http://demos.northwind.com/fbts/order/internal']/*[local-name()='ShipTo' and namespace-uri()='http://demos.northwind.com/fbts/common']/*[local-name()='Country' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Order"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.CommonTypes", typeof(global::Demos.Northwind.Schemas.CommonTypes))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.MyProperties", typeof(global::Demos.Northwind.Schemas.MyProperties))]
    public sealed class OrderInternal : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://demos.northwind.com/fbts/order/internal"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:prop=""http://Demos.Northwind.Schemas.MyProperties"" xmlns:common=""http://demos.northwind.com/fbts/common"" targetNamespace=""http://demos.northwind.com/fbts/order/internal"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:import schemaLocation=""Demos.Northwind.Schemas.CommonTypes"" namespace=""http://demos.northwind.com/fbts/common"" />
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo root_reference=""Order"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
      <b:references>
        <b:reference targetNamespace=""http://demos.northwind.com/fbts/common"" />
      </b:references>
      <b:imports>
        <b:namespace prefix=""prop"" uri=""http://Demos.Northwind.Schemas.MyProperties"" location=""Demos.Northwind.Schemas.MyProperties"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""Order"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""prop:Customer"" xpath=""/*[local-name()='Order' and namespace-uri()='http://demos.northwind.com/fbts/order/internal']/*[local-name()='CustomerID' and namespace-uri()='']"" />
          <b:property name=""prop:ShipToCountry"" xpath=""/*[local-name()='Order' and namespace-uri()='http://demos.northwind.com/fbts/order/internal']/*[local-name()='ShipTo' and namespace-uri()='http://demos.northwind.com/fbts/common']/*[local-name()='Country' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""OrderDate"" type=""xs:dateTime"" />
        <xs:element name=""CustomerID"" type=""xs:string"" />
        <xs:element name=""CompanyName"" type=""xs:string"" />
        <xs:element name=""PointOfContact"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""Name"" type=""xs:string"" />
              <xs:element name=""Title"" type=""xs:string"" />
              <xs:element name=""Phone"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element ref=""common:ShipTo"" />
        <xs:element ref=""common:BillTo"" />
        <xs:element name=""LineItems"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" ref=""common:LineItem"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""OrderTotal"" type=""xs:double"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public OrderInternal() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Order";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
