namespace Demos.Northwind.Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://demos.northwind.com/fbts/ordershipment",@"OrderShipping")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"OrderShipping"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.CommonTypes", typeof(global::Demos.Northwind.Schemas.CommonTypes))]
    public sealed class OrderShipping : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://demos.northwind.com/fbts/ordershipment"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:common=""http://demos.northwind.com/fbts/common"" targetNamespace=""http://demos.northwind.com/fbts/ordershipment"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:import schemaLocation=""Demos.Northwind.Schemas.CommonTypes"" namespace=""http://demos.northwind.com/fbts/common"" />
  <xs:annotation>
    <xs:appinfo>
      <b:references>
        <b:reference targetNamespace=""http://demos.northwind.com/fbts/common"" />
      </b:references>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""OrderShipping"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CustomerID"" type=""xs:string"" />
        <xs:element name=""PointOfContact"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""NameAndTitle"" type=""xs:string"" />
              <xs:element name=""Phone"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""OrderDate"" type=""xs:dateTime"" />
        <xs:element name=""RequiredShipDate"" type=""xs:date"" />
        <xs:element ref=""common:ShipTo"" />
        <xs:element name=""PackingSlip"">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs=""unbounded"" ref=""common:LineItem"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""OrderTotal"" type=""xs:double"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public OrderShipping() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "OrderShipping";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
