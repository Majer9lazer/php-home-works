namespace Demos.Northwind.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.OrderInternal", typeof(global::Demos.Northwind.Schemas.OrderInternal))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.OrderShipping", typeof(global::Demos.Northwind.Schemas.OrderShipping))]
    public sealed class OrderToShipping : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp"" version=""1.0"" xmlns:ns0=""http://demos.northwind.com/fbts/ordershipment"" xmlns:common=""http://demos.northwind.com/fbts/common"" xmlns:s0=""http://demos.northwind.com/fbts/order/internal"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:Order"" />
  </xsl:template>
  <xsl:template match=""/s0:Order"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringConcat(string(PointOfContact/Name/text()) , &quot;, &quot; , string(PointOfContact/Title/text()))"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:DateAddDays(string(OrderDate/text()) , &quot;5&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:StringUpperCase(string(common:ShipTo/Country/text()))"" />
    <ns0:OrderShipping>
      <CustomerID>
        <xsl:value-of select=""CustomerID/text()"" />
      </CustomerID>
      <PointOfContact>
        <NameAndTitle>
          <xsl:value-of select=""$var:v1"" />
        </NameAndTitle>
        <Phone>
          <xsl:value-of select=""PointOfContact/Phone/text()"" />
        </Phone>
        <xsl:value-of select=""PointOfContact/text()"" />
      </PointOfContact>
      <OrderDate>
        <xsl:value-of select=""OrderDate/text()"" />
      </OrderDate>
      <RequiredShipDate>
        <xsl:value-of select=""$var:v2"" />
      </RequiredShipDate>
      <common:ShipTo>
        <Addressee>
          <xsl:value-of select=""common:ShipTo/Addressee/text()"" />
        </Addressee>
        <Line1>
          <xsl:value-of select=""common:ShipTo/Line1/text()"" />
        </Line1>
        <Line2>
          <xsl:value-of select=""common:ShipTo/Line2/text()"" />
        </Line2>
        <City>
          <xsl:value-of select=""common:ShipTo/City/text()"" />
        </City>
        <Region>
          <xsl:value-of select=""common:ShipTo/Region/text()"" />
        </Region>
        <PostalCode>
          <xsl:value-of select=""common:ShipTo/PostalCode/text()"" />
        </PostalCode>
        <Country>
          <xsl:value-of select=""$var:v3"" />
        </Country>
        <xsl:value-of select=""common:ShipTo/text()"" />
      </common:ShipTo>
      <PackingSlip>
        <xsl:for-each select=""LineItems/common:LineItem"">
          <common:LineItem>
            <ProductID>
              <xsl:value-of select=""ProductID/text()"" />
            </ProductID>
            <ProductName>
              <xsl:value-of select=""ProductName/text()"" />
            </ProductName>
            <UnitPrice>
              <xsl:value-of select=""UnitPrice/text()"" />
            </UnitPrice>
            <Quantity>
              <xsl:value-of select=""Quantity/text()"" />
            </Quantity>
            <ExtendedPrice>
              <xsl:value-of select=""ExtendedPrice/text()"" />
            </ExtendedPrice>
          </common:LineItem>
        </xsl:for-each>
      </PackingSlip>
      <OrderTotal>
        <xsl:value-of select=""OrderTotal/text()"" />
      </OrderTotal>
    </ns0:OrderShipping>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringUpperCase(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.ToUpper(System.Globalization.CultureInfo.InvariantCulture);
}


public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string DateAddDays(string date, string days)
{
	string retval = """";
	double db = 0;
	if (IsDate(date) && IsNumeric(days, ref db))
	{
		DateTime dt = DateTime.Parse(date);
		int d = (int) db;
		dt = dt.AddDays(d);
		retval = dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
	}
	return retval;
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsDate(string val)
{
	bool retval = true;
	try
	{
		DateTime dt = Convert.ToDateTime(val, System.Globalization.CultureInfo.InvariantCulture);
	}
	catch (Exception)
	{
		retval = false;
	}
	return retval;
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Demos.Northwind.Schemas.OrderInternal";
        
        private const global::Demos.Northwind.Schemas.OrderInternal _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Demos.Northwind.Schemas.OrderShipping";
        
        private const global::Demos.Northwind.Schemas.OrderShipping _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Demos.Northwind.Schemas.OrderInternal";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Demos.Northwind.Schemas.OrderShipping";
                return _TrgSchemas;
            }
        }
    }
}
