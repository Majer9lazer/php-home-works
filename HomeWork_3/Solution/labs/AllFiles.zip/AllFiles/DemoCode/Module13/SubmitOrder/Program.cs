﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;

namespace InboundClient
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 3) { PrintUsage(); return; }

            string adapter  = args[0];
            string fileName = args[1];
            string url      = args[2];

            MessageVersion mv = MessageVersion.Default;

            Binding binding = null;

            switch (adapter)
            {
                case "WCF-NetTcp":
                    binding = new NetTcpBinding();
                    break;
                case "WCF-BasicHttp":
                    binding = new BasicHttpBinding();
                    mv = MessageVersion.Soap11;
                    break;
                default:
                    Console.WriteLine("Error: Unsupported adapter");
                    break;
            }

            Message msg = Message.CreateMessage(mv, "*", XmlReader.Create(fileName));

            IUniversalOneWayContract proxy = 
                    new ChannelFactory<IUniversalOneWayContract>(binding, url).CreateChannel();

            proxy.SubmitMessage(msg);

            Console.WriteLine("Message was submitted.");
        }

        private static void PrintUsage()
        {
            Console.WriteLine("Usage: SubmitOrder.exe <adapter: WCF-NetTcp | WCF-BasicHttp> <Message File Name> <url>");
            Console.ReadLine();
        }
    }

    [ServiceContract]
    public interface IUniversalOneWayContract
    {
        [OperationContract(Action = "*")]
        void SubmitMessage(Message inmsg);
    }
}
