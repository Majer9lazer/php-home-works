. ..\scripts\Functions.ps1

Get-ScriptDirectory | set-location

RemoveBTSApplication Demos.Northwind

CreateBTSApplication Demos.Northwind

ImportBTSBindingFile .\Northwind\Demos.Northwind.Bindings.xml Demos.Northwind


