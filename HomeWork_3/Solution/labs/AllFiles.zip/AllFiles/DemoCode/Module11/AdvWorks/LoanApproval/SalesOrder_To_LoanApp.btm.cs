namespace AdvWorks.LoanApproval {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.Messaging.SalesOrder", typeof(global::AdvWorks.Messaging.SalesOrder))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.LoanApproval.LoanApplication", typeof(global::AdvWorks.LoanApproval.LoanApplication))]
    public sealed class SalesOrder_To_LoanApp : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:s0=""http://AdvWorks.Messaging.SalesOrderv1.0"" xmlns:ns0=""http://LoansProcessor.LoanApp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:SalesOrder"" />
  </xsl:template>
  <xsl:template match=""/s0:SalesOrder"">
    <ns0:LoanApp>
      <LoanConditions>
        <xsl:attribute name=""LoanStatus"">
          <xsl:text />
        </xsl:attribute>
        <xsl:attribute name=""LoanAmount"">
          <xsl:value-of select=""OrderTotal/text()"" />
        </xsl:attribute>
        <xsl:attribute name=""Term"">
          <xsl:value-of select=""TermOfLoan/text()"" />
        </xsl:attribute>
        <xsl:attribute name=""LoanToIncome"">
          <xsl:text />
        </xsl:attribute>
      </LoanConditions>
      <xsl:for-each select=""CustomerInfo/Income"">
        <xsl:for-each select=""MonthlyIncome"">
          <Income>
            <xsl:if test=""@Primary"">
              <BasicSalary>
                <xsl:value-of select=""@Primary"" />
              </BasicSalary>
            </xsl:if>
            <xsl:if test=""@Other"">
              <OtherIncome>
                <xsl:value-of select=""@Other"" />
              </OtherIncome>
            </xsl:if>
          </Income>
        </xsl:for-each>
      </xsl:for-each>
      <xsl:for-each select=""CustomerInfo/Income"">
        <Employment>
          <xsl:if test=""@MonthsEmployed"">
            <TimeInMonths>
              <xsl:value-of select=""@MonthsEmployed"" />
            </TimeInMonths>
          </xsl:if>
        </Employment>
      </xsl:for-each>
      <Residency>
        <xsl:if test=""CustomerInfo/@MonthsAtResidence"">
          <TimeInMonths>
            <xsl:value-of select=""CustomerInfo/@MonthsAtResidence"" />
          </TimeInMonths>
        </xsl:if>
      </Residency>
    </ns0:LoanApp>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"AdvWorks.Messaging.SalesOrder";
        
        private const global::AdvWorks.Messaging.SalesOrder _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"AdvWorks.LoanApproval.LoanApplication";
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"AdvWorks.Messaging.SalesOrder";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"AdvWorks.LoanApproval.LoanApplication";
                return _TrgSchemas;
            }
        }
    }
}
