namespace AdvWorks.Messaging {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://AdvWorks.Messaging.SalesOrder_FFv1.0",@"SalesOrder")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "OrderDetail.Cash_Cred", XPath = @"/*[local-name()='SalesOrder' and namespace-uri()='http://AdvWorks.Messaging.SalesOrder_FFv1.0']/*[local-name()='OrderDetail' and namespace-uri()='']/@*[local-name()='Cash_Cred' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::AdvWorks.Messaging.PropertySchema.OrderType), XPath = @"/*[local-name()='SalesOrder' and namespace-uri()='http://AdvWorks.Messaging.SalesOrder_FFv1.0']/*[local-name()='OrderDetail' and namespace-uri()='']/@*[local-name()='Cash_Cred' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::AdvWorks.Messaging.PropertySchema.OrderTotal), XPath = @"/*[local-name()='SalesOrder' and namespace-uri()='http://AdvWorks.Messaging.SalesOrder_FFv1.0']/*[local-name()='OrderDetail' and namespace-uri()='']/*[local-name()='TotalOrder' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"SalesOrder"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.Messaging.PropertySchema.PropertySchema", typeof(global::AdvWorks.Messaging.PropertySchema.PropertySchema))]
    public sealed class SalesOrder_FF : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://AdvWorks.Messaging.SalesOrder_FFv1.0"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ns0=""http://AdvWorks.Messaging.PropertySchema.PropertySchema"" targetNamespace=""http://AdvWorks.Messaging.SalesOrder_FFv1.0"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo default_pad_char="" "" count_positions_by_byte=""false"" parser_optimization=""speed"" lookahead_depth=""3"" suppress_empty_nodes=""false"" generate_empty_nodes=""true"" allow_early_termination=""false"" allow_message_breakup_of_infix_root=""false"" compile_parse_tables=""false"" standard=""Flat File"" root_reference=""SalesOrder"" early_terminate_optional_fields=""false"" pad_char_type=""char"" />
      <schemaEditorExtension:schemaInfo namespaceAlias=""b"" extensionClass=""Microsoft.BizTalk.FlatFileExtension.FlatFileExtension"" standardName=""Flat File"" xmlns:schemaEditorExtension=""http://schemas.microsoft.com/BizTalk/2003/SchemaEditorExtensions"" />
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""http://AdvWorks.Messaging.PropertySchema.PropertySchema"" location=""AdvWorks.Messaging.PropertySchema.PropertySchema"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""SalesOrder"">
    <xs:annotation>
      <xs:appinfo>
        <b:recordInfo structure=""delimited"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" sequence_number=""1"" child_delimiter_type=""hex"" child_delimiter=""0x0D 0x0A"" child_order=""postfix"" />
        <b:properties>
          <b:property distinguished=""true"" xpath=""/*[local-name()='SalesOrder' and namespace-uri()='http://AdvWorks.Messaging.SalesOrder_FFv1.0']/*[local-name()='OrderDetail' and namespace-uri()='']/@*[local-name()='Cash_Cred' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='SalesOrder' and namespace-uri()='http://AdvWorks.Messaging.SalesOrder_FFv1.0']/*[local-name()='OrderTotal' and namespace-uri()='']"" />
          <b:property name=""ns0:OrderType"" xpath=""/*[local-name()='SalesOrder' and namespace-uri()='http://AdvWorks.Messaging.SalesOrder_FFv1.0']/*[local-name()='OrderDetail' and namespace-uri()='']/@*[local-name()='Cash_Cred' and namespace-uri()='']"" />
          <b:property name=""ns0:OrderTotal"" xpath=""/*[local-name()='SalesOrder' and namespace-uri()='http://AdvWorks.Messaging.SalesOrder_FFv1.0']/*[local-name()='OrderDetail' and namespace-uri()='']/*[local-name()='TotalOrder' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:annotation>
          <xs:appinfo>
            <b:groupInfo sequence_number=""0"" />
          </xs:appinfo>
        </xs:annotation>
        <xs:element name=""OrderDetail"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""delimited"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" sequence_number=""1"" child_order=""infix"" child_delimiter_type=""char"" child_delimiter="","" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <b:groupInfo sequence_number=""0"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element name=""CreditInfo"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:recordInfo sequence_number=""5"" structure=""delimited"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" child_delimiter_type=""char"" child_order=""infix"" child_delimiter="","" />
                  </xs:appinfo>
                </xs:annotation>
                <xs:complexType>
                  <xs:attribute name=""Employer"" type=""xs:string"">
                    <xs:annotation>
                      <xs:appinfo>
                        <b:fieldInfo justification=""left"" sequence_number=""1"" />
                      </xs:appinfo>
                    </xs:annotation>
                  </xs:attribute>
                  <xs:attribute name=""MonthsEmployed"" type=""xs:string"">
                    <xs:annotation>
                      <xs:appinfo>
                        <b:fieldInfo justification=""left"" sequence_number=""2"" />
                      </xs:appinfo>
                    </xs:annotation>
                  </xs:attribute>
                  <xs:attribute name=""PrimaryIncome"" type=""xs:string"">
                    <xs:annotation>
                      <xs:appinfo>
                        <b:fieldInfo justification=""left"" pos_length=""8"" sequence_number=""3"" />
                      </xs:appinfo>
                    </xs:annotation>
                  </xs:attribute>
                  <xs:attribute name=""OtherIncome"" type=""xs:string"">
                    <xs:annotation>
                      <xs:appinfo>
                        <b:fieldInfo justification=""left"" pos_length=""8"" sequence_number=""4"" />
                      </xs:appinfo>
                    </xs:annotation>
                  </xs:attribute>
                </xs:complexType>
              </xs:element>
              <xs:element name=""TotalOrder"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" sequence_number=""6"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
            </xs:sequence>
            <xs:attribute name=""StoreNumber"" type=""xs:string"">
              <xs:annotation>
                <xs:appinfo>
                  <b:fieldInfo justification=""left"" sequence_number=""1"" />
                </xs:appinfo>
              </xs:annotation>
            </xs:attribute>
            <xs:attribute name=""OrderNumber"" type=""xs:string"">
              <xs:annotation>
                <xs:appinfo>
                  <b:fieldInfo justification=""left"" sequence_number=""2"" />
                </xs:appinfo>
              </xs:annotation>
            </xs:attribute>
            <xs:attribute name=""Cash_Cred"">
              <xs:annotation>
                <xs:appinfo>
                  <b:fieldInfo justification=""left"" sequence_number=""3"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:simpleType>
                <xs:restriction base=""xs:string"">
                  <xs:enumeration value=""CASH"" />
                  <xs:enumeration value=""CRED"" />
                  <xs:enumeration value=""Cash"" />
                  <xs:enumeration value=""Credit"" />
                </xs:restriction>
              </xs:simpleType>
            </xs:attribute>
            <xs:attribute name=""Employee"" type=""xs:string"">
              <xs:annotation>
                <xs:appinfo>
                  <b:fieldInfo justification=""left"" sequence_number=""4"" />
                </xs:appinfo>
              </xs:annotation>
            </xs:attribute>
          </xs:complexType>
        </xs:element>
        <xs:element name=""CustomerInfo"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""positional"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" sequence_number=""2"" child_delimiter_type=""char"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <b:groupInfo sequence_number=""0"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element name=""Address"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" sequence_number=""4"" pos_length=""25"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element name=""Town"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" sequence_number=""5"" pos_length=""10"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element name=""Region"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" sequence_number=""6"" pos_length=""2"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element name=""ZipCode"" type=""xs:string"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" sequence_number=""7"" pos_length=""5"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
            </xs:sequence>
            <xs:attribute name=""ID"" type=""xs:string"">
              <xs:annotation>
                <xs:appinfo>
                  <b:fieldInfo justification=""left"" sequence_number=""1"" pos_length=""5"" />
                </xs:appinfo>
              </xs:annotation>
            </xs:attribute>
            <xs:attribute name=""CustomerName"" type=""xs:string"">
              <xs:annotation>
                <xs:appinfo>
                  <b:fieldInfo justification=""left"" sequence_number=""2"" pos_length=""25"" />
                </xs:appinfo>
              </xs:annotation>
            </xs:attribute>
            <xs:attribute name=""MonthsAtResidence"" type=""xs:string"">
              <xs:annotation>
                <xs:appinfo>
                  <b:fieldInfo justification=""left"" sequence_number=""3"" pos_length=""4"" />
                </xs:appinfo>
              </xs:annotation>
            </xs:attribute>
          </xs:complexType>
        </xs:element>
        <xs:element name=""Products"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""delimited"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" sequence_number=""3"" child_delimiter_type=""char"" child_delimiter="","" child_order=""prefix"" tag_name=""PRODUCTS"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <b:groupInfo sequence_number=""0"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element maxOccurs=""unbounded"" name=""Product"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:recordInfo structure=""delimited"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" sequence_number=""1"" child_delimiter_type=""char"" child_delimiter=""|"" tag_name=""PRODUCT"" />
                  </xs:appinfo>
                </xs:annotation>
                <xs:complexType>
                  <xs:attribute name=""Quantity"" type=""xs:nonNegativeInteger"">
                    <xs:annotation>
                      <xs:appinfo>
                        <b:fieldInfo justification=""left"" sequence_number=""1"" />
                      </xs:appinfo>
                    </xs:annotation>
                  </xs:attribute>
                  <xs:attribute name=""ItemNumber"" type=""xs:string"">
                    <xs:annotation>
                      <xs:appinfo>
                        <b:fieldInfo justification=""left"" sequence_number=""2"" />
                      </xs:appinfo>
                    </xs:annotation>
                  </xs:attribute>
                  <xs:attribute name=""PriceEach"" type=""xs:decimal"">
                    <xs:annotation>
                      <xs:appinfo>
                        <b:fieldInfo justification=""left"" sequence_number=""3"" />
                      </xs:appinfo>
                    </xs:annotation>
                  </xs:attribute>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""Comment"" type=""xs:string"">
          <xs:annotation>
            <xs:appinfo>
              <b:fieldInfo justification=""left"" sequence_number=""4"" />
            </xs:appinfo>
          </xs:annotation>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public SalesOrder_FF() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "SalesOrder";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
