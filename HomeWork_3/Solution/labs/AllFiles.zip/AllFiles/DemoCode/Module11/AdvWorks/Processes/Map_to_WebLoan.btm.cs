namespace AdvWorks.Processes {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.LoanApproval.FinalLoanDocument", typeof(global::AdvWorks.LoanApproval.FinalLoanDocument))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.Processes.SubmitLoan.Reference", typeof(global::AdvWorks.Processes.SubmitLoan.Reference))]
    public sealed class Map_to_WebLoan : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:ns0=""http://AdvWorks.LoanApproval.SimpleLoanDocument"" xmlns:s0=""http://AdvWorks.Processes.ManualApprovalProcessing"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:FinalLoan"" />
  </xsl:template>
  <xsl:template match=""/s0:FinalLoan"">
    <ns0:Loan>
      <xsl:attribute name=""CUSTOMER"">
        <xsl:value-of select=""CustomerName/text()"" />
      </xsl:attribute>
      <xsl:attribute name=""TERM"">
        <xsl:value-of select=""Loan/Term/text()"" />
      </xsl:attribute>
      <xsl:attribute name=""AMOUNT"">
        <xsl:value-of select=""Loan/Amount/text()"" />
      </xsl:attribute>
      <xsl:attribute name=""STATUS"">
        <xsl:value-of select=""Loan/Status/text()"" />
      </xsl:attribute>
      <xsl:if test=""Address/@State"">
        <xsl:attribute name=""STATE"">
          <xsl:value-of select=""Address/@State"" />
        </xsl:attribute>
      </xsl:if>
    </ns0:Loan>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"AdvWorks.LoanApproval.FinalLoanDocument";
        
        private const global::AdvWorks.LoanApproval.FinalLoanDocument _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"AdvWorks.Processes.SubmitLoan.Reference";
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"AdvWorks.LoanApproval.FinalLoanDocument";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"AdvWorks.Processes.SubmitLoan.Reference";
                return _TrgSchemas;
            }
        }
    }
}
