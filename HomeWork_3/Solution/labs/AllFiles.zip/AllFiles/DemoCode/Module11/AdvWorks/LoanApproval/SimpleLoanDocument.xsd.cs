namespace AdvWorks.LoanApproval {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://AdvWorks.LoanApproval.SimpleLoanDocument",@"Loan")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "STATE", XPath = @"/*[local-name()='Loan' and namespace-uri()='http://AdvWorks.LoanApproval.SimpleLoanDocument']/@*[local-name()='STATE' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::AdvWorks.Messaging.PropertySchema.CustomerName), XPath = @"/*[local-name()='Loan' and namespace-uri()='http://AdvWorks.LoanApproval.SimpleLoanDocument']/@*[local-name()='CUSTOMER' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(global::AdvWorks.Messaging.PropertySchema.OrderTotal), XPath = @"/*[local-name()='Loan' and namespace-uri()='http://AdvWorks.LoanApproval.SimpleLoanDocument']/@*[local-name()='AMOUNT' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Loan"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.Messaging.PropertySchema.PropertySchema", typeof(global::AdvWorks.Messaging.PropertySchema.PropertySchema))]
    public sealed class SimpleLoanDocument : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://AdvWorks.LoanApproval.SimpleLoanDocument"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:ps1=""http://AdvWorks.Messaging.PropertySchema.PropertySchema"" targetNamespace=""http://AdvWorks.LoanApproval.SimpleLoanDocument"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ps1"" uri=""http://AdvWorks.Messaging.PropertySchema.PropertySchema"" location=""AdvWorks.Messaging.PropertySchema.PropertySchema"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""Loan"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property distinguished=""true"" xpath=""/*[local-name()='Loan' and namespace-uri()='http://AdvWorks.LoanApproval.SimpleLoanDocument']/@*[local-name()='STATE' and namespace-uri()='']"" />
          <b:property name=""ps1:CustomerName"" xpath=""/*[local-name()='Loan' and namespace-uri()='http://AdvWorks.LoanApproval.SimpleLoanDocument']/@*[local-name()='CUSTOMER' and namespace-uri()='']"" />
          <b:property name=""ps1:OrderTotal"" xpath=""/*[local-name()='Loan' and namespace-uri()='http://AdvWorks.LoanApproval.SimpleLoanDocument']/@*[local-name()='AMOUNT' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:attribute name=""CUSTOMER"" type=""xs:string"" />
      <xs:attribute name=""TERM"" type=""xs:string"" />
      <xs:attribute name=""AMOUNT"" type=""xs:string"" />
      <xs:attribute name=""STATUS"" type=""xs:string"" />
      <xs:attribute name=""STATE"" type=""xs:string"" />
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        private const global::AdvWorks.Messaging.PropertySchema.PropertySchema  __DummyVar0 = null;
        
        public SimpleLoanDocument() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Loan";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
