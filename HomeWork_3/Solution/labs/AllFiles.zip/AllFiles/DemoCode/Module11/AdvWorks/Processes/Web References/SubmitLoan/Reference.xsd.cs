namespace AdvWorks.Processes.SubmitLoan {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://AdvWorks.LoanApproval.SimpleLoanDocument",@"Loan")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Loan"})]
    public sealed class Reference : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:tns=""http://AdvWorks.LoanApproval.SimpleLoanDocument"" elementFormDefault=""qualified"" targetNamespace=""http://AdvWorks.LoanApproval.SimpleLoanDocument"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""Loan"" nillable=""true"">
    <xs:complexType>
      <xs:attribute name=""CUSTOMER"" type=""xs:string"" />
      <xs:attribute name=""TERM"" type=""xs:string"" />
      <xs:attribute name=""AMOUNT"" type=""xs:string"" />
      <xs:attribute name=""STATUS"" type=""xs:string"" />
      <xs:attribute name=""STATE"" type=""xs:string"" />
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Reference() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Loan";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
