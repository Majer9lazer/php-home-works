namespace AdvWorks.LoanApproval {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.Messaging.SalesOrder", typeof(global::AdvWorks.Messaging.SalesOrder))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"AdvWorks.LoanApproval.FinalLoanDocument", typeof(global::AdvWorks.LoanApproval.FinalLoanDocument))]
    public sealed class SalesOrder_to_FinalLoan : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:s0=""http://AdvWorks.Messaging.SalesOrderv1.0"" xmlns:ns0=""http://AdvWorks.Processes.ManualApprovalProcessing"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:SalesOrder"" />
  </xsl:template>
  <xsl:template match=""/s0:SalesOrder"">
    <ns0:FinalLoan>
      <xsl:if test=""CustomerInfo/@CustomerName"">
        <CustomerName>
          <xsl:value-of select=""CustomerInfo/@CustomerName"" />
        </CustomerName>
      </xsl:if>
      <Address>
        <xsl:attribute name=""Street"">
          <xsl:value-of select=""CustomerInfo/BillingAddress/Street/text()"" />
        </xsl:attribute>
        <xsl:attribute name=""City"">
          <xsl:value-of select=""CustomerInfo/BillingAddress/City/text()"" />
        </xsl:attribute>
        <xsl:attribute name=""State"">
          <xsl:value-of select=""CustomerInfo/BillingAddress/State/text()"" />
        </xsl:attribute>
        <xsl:attribute name=""Zip"">
          <xsl:value-of select=""CustomerInfo/BillingAddress/PostalCode/text()"" />
        </xsl:attribute>
        <xsl:if test=""CustomerInfo/@MonthsAtResidence"">
          <xsl:attribute name=""TimeAtResidence"">
            <xsl:value-of select=""CustomerInfo/@MonthsAtResidence"" />
          </xsl:attribute>
        </xsl:if>
      </Address>
      <xsl:for-each select=""CustomerInfo/Income"">
        <Employment>
          <xsl:if test=""@Employer"">
            <xsl:attribute name=""Employer"">
              <xsl:value-of select=""@Employer"" />
            </xsl:attribute>
          </xsl:if>
          <xsl:if test=""@MonthsEmployed"">
            <xsl:attribute name=""TimeAtEmployer"">
              <xsl:value-of select=""@MonthsEmployed"" />
            </xsl:attribute>
          </xsl:if>
        </Employment>
      </xsl:for-each>
      <xsl:if test=""CustomerInfo/Income/MonthlyIncome/@Primary"">
        <PrimaryIncome>
          <xsl:value-of select=""CustomerInfo/Income/MonthlyIncome/@Primary"" />
        </PrimaryIncome>
      </xsl:if>
      <xsl:if test=""CustomerInfo/Income/MonthlyIncome/@Other"">
        <OtherIncome>
          <xsl:value-of select=""CustomerInfo/Income/MonthlyIncome/@Other"" />
        </OtherIncome>
      </xsl:if>
      <Loan>
        <Status>
          <xsl:text />
        </Status>
        <Amount>
          <xsl:value-of select=""OrderTotal/text()"" />
        </Amount>
        <Term>
          <xsl:value-of select=""TermOfLoan/text()"" />
        </Term>
        <LoanToIncomeRatio>
          <xsl:text />
        </LoanToIncomeRatio>
      </Loan>
    </ns0:FinalLoan>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"AdvWorks.Messaging.SalesOrder";
        
        private const global::AdvWorks.Messaging.SalesOrder _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"AdvWorks.LoanApproval.FinalLoanDocument";
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"AdvWorks.Messaging.SalesOrder";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"AdvWorks.LoanApproval.FinalLoanDocument";
                return _TrgSchemas;
            }
        }
    }
}
