. ..\scripts\Functions.ps1

Get-ScriptDirectory | set-location

RemoveBTSApplication Demos.Northwind

CreateBTSApplication BAMInterceptors

BuildVSSolution .\BAM.sln

DeployVSSolution .\BAM.sln

ImportBTSBindingFile .\bindingfile.xml BAMInterceptors

StartBTSApplication BAMInterceptors

