﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace OrchMessageUtilities
{
    public class MessageFactory
    {
        static XmlDocument template;

        static MessageFactory()
        {
            template = new XmlDocument();
            template.LoadXml("<ShipNotice><OrderID></OrderID></ShipNotice>");
        }

        public static XmlDocument CreateShipNotice()
        {
            return (XmlDocument)template.CloneNode(true);
        }
    }
}
