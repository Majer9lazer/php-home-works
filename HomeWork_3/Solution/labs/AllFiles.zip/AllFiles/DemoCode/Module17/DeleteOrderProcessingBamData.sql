DELETE FROM [BAMPrimaryImport].[dbo].[bam_OrderProcessing_Continuations]
DELETE FROM [BAMPrimaryImport].[dbo].[bam_OrderProcessing_CompletedRelationships]
DELETE FROM [BAMPrimaryImport].[dbo].[bam_OrderProcessing_Completed]
DELETE FROM [BAMPrimaryImport].[dbo].[bam_OrderProcessing_ActiveRelationships]
DELETE FROM [BAMPrimaryImport].[dbo].[bam_OrderProcessing_Active]
GO
