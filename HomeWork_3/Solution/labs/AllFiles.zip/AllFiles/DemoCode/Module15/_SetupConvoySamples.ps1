. ..\scripts\Functions.ps1

Get-ScriptDirectory | set-location

RemoveBTSApplication Demos.Northwind

CreateBTSApplication Demos.Northwind

BuildVSSolution .\ConvoySamples\ConvoySamples.sln

DeployVSSolution .\ConvoySamples\ConvoySamples.sln

ImportBTSBindingFile .\ConvoySamples\ConvoySamples.Binding.xml Demos.Northwind

StartBTSApplication Demos.Northwind

UnenlistOrchestration ConvoyOrchestrations.ParallelConvoy
