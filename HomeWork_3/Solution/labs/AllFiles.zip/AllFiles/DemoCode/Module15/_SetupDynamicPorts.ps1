. ..\scripts\Functions.ps1

Get-ScriptDirectory | set-location

RemoveBTSApplication Demos.Northwind

CreateBTSApplication Demos.Northwind

BuildVSSolution .\DynamicPorts\DynamicPorts.sln

DeployVSSolution .\DynamicPorts\DynamicPorts.sln

ImportBTSBindingFile .\DynamicPorts\DynamicPorts.Binding.xml Demos.Northwind

