namespace Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"ZipCode", @"Address"})]
    public sealed class Common : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns=""http://Northwind.com/common"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" targetNamespace=""http://Northwind.com/common"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""ZipCode"" type=""ZipCodeType"" />
  <xs:simpleType name=""ZipCodeType"">
    <xs:restriction base=""xs:string"">
      <xs:pattern value=""\d{5}-\d{4}"" />
    </xs:restriction>
  </xs:simpleType>
  <xs:complexType name=""AddressType"">
    <xs:sequence>
      <xs:element name=""Street"" type=""xs:string"" />
      <xs:element minOccurs=""0"" maxOccurs=""1"" name=""Street2"" type=""xs:string"" />
      <xs:element name=""City"" type=""xs:string"" />
      <xs:element name=""Region"" type=""xs:string"" />
      <xs:element name=""PostalCode"" type=""ZipCodeType"" />
      <xs:element name=""Country"" type=""xs:string"" />
    </xs:sequence>
    <xs:attribute name=""Label"">
      <xs:simpleType>
        <xs:restriction base=""xs:string"">
          <xs:enumeration value=""Shipping"" />
          <xs:enumeration value=""Billing"" />
        </xs:restriction>
      </xs:simpleType>
    </xs:attribute>
  </xs:complexType>
  <xs:element name=""Address"" type=""AddressType"" />
</xs:schema>";
        
        public Common() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [2];
                _RootElements[0] = "ZipCode";
                _RootElements[1] = "Address";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
        
        [Schema(@"http://Northwind.com/common",@"ZipCode")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"ZipCode"})]
        public sealed class ZipCode : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public ZipCode() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "ZipCode";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://Northwind.com/common",@"Address")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"Address"})]
        public sealed class Address : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public Address() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "Address";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
    }
}
