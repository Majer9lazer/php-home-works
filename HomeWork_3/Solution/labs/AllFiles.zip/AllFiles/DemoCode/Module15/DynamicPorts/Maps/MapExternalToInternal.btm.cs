namespace Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Schemas.OrderExternal", typeof(global::Schemas.OrderExternal))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Schemas.InternalOrder", typeof(global::Schemas.InternalOrder))]
    public sealed class MapExternalToInternal : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 ScriptNS0 userCSharp"" version=""1.0"" xmlns:ns0=""http://Northwind.com/ordering"" xmlns:s0=""http://demos.northwind.com/fbts/order/external"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:OrderExternal"" />
  </xsl:template>
  <xsl:template match=""/s0:OrderExternal"">
    <ns0:InternalOrder>
      <xsl:variable name=""var:v1"" select=""ScriptNS0:DBLookup(0 , string(CustomerID/text()) , &quot;provider=sqloledb;database=northwind;server=.;integrated security=SSPI&quot; , &quot;Customers&quot; , &quot;CustomerID&quot;)"" />
      <xsl:variable name=""var:v2"" select=""ScriptNS0:DBValueExtract(string($var:v1) , &quot;ContactName&quot;)"" />
      <CustomerName>
        <xsl:value-of select=""$var:v2"" />
      </CustomerName>
      <xsl:for-each select=""Addresses/Address"">
        <xsl:variable name=""var:v3"" select=""userCSharp:LogicalEq(string(@Label) , &quot;ShipTo&quot;)"" />
        <xsl:if test=""$var:v3"">
          <xsl:variable name=""var:v4"" select=""userCSharp:StringConcat(string(Line1/text()) , string(Line2/text()))"" />
          <ShippingAddress>
            <Street>
              <xsl:value-of select=""$var:v4"" />
            </Street>
            <City>
              <xsl:value-of select=""City/text()"" />
            </City>
            <Region>
              <xsl:value-of select=""Region/text()"" />
            </Region>
            <PostalCode>
              <xsl:value-of select=""PostalCode/text()"" />
            </PostalCode>
            <Country>
              <xsl:value-of select=""Country/text()"" />
            </Country>
          </ShippingAddress>
        </xsl:if>
      </xsl:for-each>
      <xsl:for-each select=""Addresses/Address"">
        <xsl:variable name=""var:v5"" select=""string(@Label)"" />
        <xsl:variable name=""var:v6"" select=""userCSharp:LogicalEq($var:v5 , &quot;BillTo&quot;)"" />
        <xsl:if test=""$var:v6"">
          <xsl:variable name=""var:v7"" select=""string(Line1/text())"" />
          <xsl:variable name=""var:v8"" select=""string(Line2/text())"" />
          <xsl:variable name=""var:v9"" select=""userCSharp:StringConcat($var:v7 , $var:v8)"" />
          <BillingAddress>
            <Street>
              <xsl:value-of select=""$var:v9"" />
            </Street>
            <City>
              <xsl:value-of select=""City/text()"" />
            </City>
            <Region>
              <xsl:value-of select=""Region/text()"" />
            </Region>
            <PostalCode>
              <xsl:value-of select=""PostalCode/text()"" />
            </PostalCode>
            <Country>
              <xsl:value-of select=""Country/text()"" />
            </Country>
          </BillingAddress>
        </xsl:if>
      </xsl:for-each>
      <Items>
        <xsl:for-each select=""Items/Item"">
          <Item>
            <ProductID>
              <xsl:value-of select=""Sku/text()"" />
            </ProductID>
            <Price>
              <xsl:value-of select=""Price/text()"" />
            </Price>
            <Quantity>
              <xsl:value-of select=""Quantity/text()"" />
            </Quantity>
          </Item>
        </xsl:for-each>
      </Items>
    </ns0:InternalOrder>
    <xsl:variable name=""var:v10"" select=""ScriptNS0:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringConcat(string param0, string param1)
{
   return param0 + param1;
}


public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Schemas.OrderExternal";
        
        private const global::Schemas.OrderExternal _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Schemas.InternalOrder";
        
        private const global::Schemas.InternalOrder _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Schemas.OrderExternal";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Schemas.InternalOrder";
                return _TrgSchemas;
            }
        }
    }
}
