
#pragma warning disable 162

namespace Orchestrations
{

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "SubmitBilling",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_OrderBilling)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "SubmitShipping",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_OrderShipping)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class InputPortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public InputPortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public InputPortType(InputPortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            InputPortType p = new InputPortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo SubmitBilling = new Microsoft.XLANGs.Core.OperationInfo
        (
            "SubmitBilling",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(InputPortType),
            typeof(__messagetype_Schemas_OrderBilling),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public Microsoft.XLANGs.Core.OperationInfo SubmitShipping = new Microsoft.XLANGs.Core.OperationInfo
        (
            "SubmitShipping",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(InputPortType),
            typeof(__messagetype_Schemas_OrderShipping),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "SubmitBilling" ] = SubmitBilling;
                h[ "SubmitShipping" ] = SubmitShipping;
                return h;
            }
        }
        #endregion // port reflection support
    }

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "auditBilling",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_OrderBilling)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "auditshipping",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_OrderShipping)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class AuditPortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public AuditPortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public AuditPortType(AuditPortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            AuditPortType p = new AuditPortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo auditBilling = new Microsoft.XLANGs.Core.OperationInfo
        (
            "auditBilling",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(AuditPortType),
            typeof(__messagetype_Schemas_OrderBilling),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public Microsoft.XLANGs.Core.OperationInfo auditshipping = new Microsoft.XLANGs.Core.OperationInfo
        (
            "auditshipping",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(AuditPortType),
            typeof(__messagetype_Schemas_OrderShipping),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "auditBilling" ] = auditBilling;
                h[ "auditshipping" ] = auditshipping;
                return h;
            }
        }
        #endregion // port reflection support
    }
    [Microsoft.XLANGs.BaseTypes.CorrelationTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal,
        new string[] {
            "Schemas.CustomerID"
        }
    )]
    sealed internal class CustomerCorrelation : Microsoft.XLANGs.Core.CorrelationType
    {
        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        private static Microsoft.XLANGs.BaseTypes.PropertyBase[] _properties = new Microsoft.XLANGs.BaseTypes.PropertyBase[] {
            new Schemas.CustomerID()
         };
        public override Microsoft.XLANGs.BaseTypes.PropertyBase[] Properties { get { return _properties; } }
        public static Microsoft.XLANGs.BaseTypes.PropertyBase[] PropertiesList { get { return _properties; } }
    }
    //#line 249 "C:\Northwind\demos\OrchII\ConvoySamples\Orchestrations\ParallelConvoy.odx"
    [Microsoft.XLANGs.BaseTypes.StaticConvoyAttribute(
        0,
        new System.Type[] { typeof(CustomerCorrelation) }
    )]
    [Microsoft.XLANGs.BaseTypes.StaticSubscriptionAttribute(
        0, "InputPort", "SubmitBilling", -1, 0, true
    )]
    [Microsoft.XLANGs.BaseTypes.StaticSubscriptionAttribute(
        1, "InputPort", "SubmitShipping", -1, 0, true
    )]
    [Microsoft.XLANGs.BaseTypes.ServicePortsAttribute(
        new Microsoft.XLANGs.BaseTypes.EXLangSParameter[] {
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        },
        new System.Type[] {
            typeof(Orchestrations.InputPortType),
            typeof(Orchestrations.AuditPortType)
        },
        new System.String[] {
            "InputPort",
            "AuditPort"
        },
        new System.Type[] {
            null,
            null
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceCallTreeAttribute(
        new System.Type[] {
        },
        new System.Type[] {
        },
        new System.Type[] {
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal,
        Microsoft.XLANGs.BaseTypes.EXLangSServiceInfo.eNone
    )]
    [System.SerializableAttribute]
    [Microsoft.XLANGs.BaseTypes.BPELExportableAttribute(false)]
    sealed internal class ParallelConvoy : Microsoft.BizTalk.XLANGs.BTXEngine.BTXService
    {
        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        public static readonly bool __execable = false;
        [Microsoft.XLANGs.BaseTypes.CallCompensationAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSCallCompensationInfo.eNone,
            new System.String[] {
            },
            new System.String[] {
            }
        )]
        public static void __bodyProxy()
        {
        }
        private static System.Guid _serviceId = Microsoft.XLANGs.Core.HashHelper.HashServiceType(typeof(ParallelConvoy));
        private static volatile System.Guid[] _activationSubIds;

        private static new object _lockIdentity = new object();

        public static System.Guid UUID { get { return _serviceId; } }
        public override System.Guid ServiceId { get { return UUID; } }

        protected override System.Guid[] ActivationSubGuids
        {
            get { return _activationSubIds; }
            set { _activationSubIds = value; }
        }

        protected override object StaleStateLock
        {
            get { return _lockIdentity; }
        }

        protected override bool HasActivation { get { return true; } }

        internal bool IsExeced = false;

        static ParallelConvoy()
        {
            Microsoft.BizTalk.XLANGs.BTXEngine.BTXService.CacheStaticState( _serviceId );
        }

        private void ConstructorHelper()
        {
            _segments = new Microsoft.XLANGs.Core.Segment[] {
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment0), 0, 0, 0),
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment1), 1, 1, 1),
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment2), 1, 1, 2),
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment3), 1, 1, 3)
            };

            _Locks = 0;
            _rootContext = new __ParallelConvoy_root_0(this);
            _stateMgrs = new Microsoft.XLANGs.Core.IStateManager[2];
            _stateMgrs[0] = _rootContext;
            FinalConstruct();
        }

        public ParallelConvoy(System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXSession session, Microsoft.BizTalk.XLANGs.BTXEngine.BTXEvents tracker)
            : base(instanceId, session, "ParallelConvoy", tracker)
        {
            ConstructorHelper();
        }

        public ParallelConvoy(int callIndex, System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXService parent)
            : base(callIndex, instanceId, parent, "ParallelConvoy")
        {
            ConstructorHelper();
        }

        private const string _symInfo = @"
<XsymFile>
<ProcessFlow xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>      <shapeType>RootShape</shapeType>      <ShapeID>7faedcbf-3fb3-4d52-ae91-37c48ec5255b</ShapeID>      
<children>                          
<ShapeInfo>      <shapeType>ParallelShape</shapeType>      <ShapeID>30cc84ef-2e1e-47a7-b809-80a4b057e982</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>ParallelActions_1</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>ParallelBranchShape</shapeType>      <ShapeID>2cb55593-b162-4a54-adad-04df11300002</ShapeID>      <ParentLink>ReallyComplexStatement_Branch</ParentLink>                <shapeText>ParallelBranch_1</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>70b57a52-53e0-4fc3-aed7-7b90e4b965c5</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Receive_Billing</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>7ae6233a-d10a-43e8-b76d-2cc844d582d6</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Send_BillingAudit</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ParallelBranchShape</shapeType>      <ShapeID>c4e720a6-0823-45f5-88dc-a7131f5c9e5c</ShapeID>      <ParentLink>ReallyComplexStatement_Branch</ParentLink>                <shapeText>ParallelBranch_2</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>48a55ca1-25d7-496c-b257-d6f9c5ce0482</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Receive_Shipping</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>ef311dbe-35d2-4349-b4ae-cf373a9fb317</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Send_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                  </children>
  </ProcessFlow>
<Metadata>

<TrkMetadata>
<ActionName>'ParallelConvoy'</ActionName><IsAtomic>0</IsAtomic><Line>249</Line><Position>14</Position><ShapeID>'e211a116-cb8b-44e7-a052-0de295aa0001'</ShapeID>
</TrkMetadata>

<TrkMetadata>
<Line>261</Line><Position>13</Position><ShapeID>'30cc84ef-2e1e-47a7-b809-80a4b057e982'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>266</Line><Position>30</Position><ShapeID>'70b57a52-53e0-4fc3-aed7-7b90e4b965c5'</ShapeID>
<Messages>
	<MsgInfo><name>Billing</name><part>part</part><schema>Schemas.OrderBilling</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>268</Line><Position>21</Position><ShapeID>'7ae6233a-d10a-43e8-b76d-2cc844d582d6'</ShapeID>
<Messages>
	<MsgInfo><name>Billing</name><part>part</part><schema>Schemas.OrderBilling</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>273</Line><Position>30</Position><ShapeID>'48a55ca1-25d7-496c-b257-d6f9c5ce0482'</ShapeID>
<Messages>
	<MsgInfo><name>Shipping</name><part>part</part><schema>Schemas.OrderShipping</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>275</Line><Position>21</Position><ShapeID>'ef311dbe-35d2-4349-b4ae-cf373a9fb317'</ShapeID>
<Messages>
	<MsgInfo><name>Shipping</name><part>part</part><schema>Schemas.OrderShipping</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>
</Metadata>
</XsymFile>";

        public override string odXml { get { return _symODXML; } }

        private const string _symODXML = @"
<?xml version='1.0' encoding='utf-8' standalone='yes'?>
<om:MetaModel MajorVersion='1' MinorVersion='3' Core='2b131234-7959-458d-834f-2dc0769ce683' ScheduleModel='66366196-361d-448d-976f-cab5e87496d2' xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>
    <om:Element Type='Module' OID='db7c05d4-9e5a-43ec-96d5-115fb3e18ebb' LowerBound='1.1' HigherBound='63.1'>
        <om:Property Name='ReportToAnalyst' Value='True' />
        <om:Property Name='Name' Value='Orchestrations' />
        <om:Property Name='Signal' Value='False' />
        <om:Element Type='PortType' OID='5fffb312-acbc-42b2-92cc-bb6227a69bce' ParentLink='Module_PortType' LowerBound='4.1' HigherBound='15.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='InputPortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='e7b42aef-9def-4480-81fc-7c8dcc7d5679' ParentLink='PortType_OperationDeclaration' LowerBound='6.1' HigherBound='10.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='SubmitBilling' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='MessageRef' OID='23f6116e-2aa8-4016-b1e0-673c8fc46f66' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='8.13' HigherBound='8.33'>
                    <om:Property Name='Ref' Value='Schemas.OrderBilling' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='OperationDeclaration' OID='02b332fe-71e2-44c3-b72e-6e6c14b83fc0' ParentLink='PortType_OperationDeclaration' LowerBound='10.1' HigherBound='14.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='SubmitShipping' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='MessageRef' OID='8dc247b1-d9ca-49d0-950e-59d54dc13a86' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='12.13' HigherBound='12.34'>
                    <om:Property Name='Ref' Value='Schemas.OrderShipping' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='PortType' OID='df9ea439-6f55-461c-9df2-9fb7b7cbafe3' ParentLink='Module_PortType' LowerBound='15.1' HigherBound='26.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='AuditPortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='89cf20c7-ddb2-4b10-8cf9-1cfd02de3dc1' ParentLink='PortType_OperationDeclaration' LowerBound='17.1' HigherBound='21.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='auditBilling' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='MessageRef' OID='1cfed616-e2dd-4ef4-b55d-0eac9b3516e7' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='19.13' HigherBound='19.33'>
                    <om:Property Name='Ref' Value='Schemas.OrderBilling' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='OperationDeclaration' OID='8736395b-7c25-4800-8938-ec9b388bddc9' ParentLink='PortType_OperationDeclaration' LowerBound='21.1' HigherBound='25.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='auditshipping' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='MessageRef' OID='c31b0aff-691e-41e6-80b6-52423995e777' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='23.13' HigherBound='23.34'>
                    <om:Property Name='Ref' Value='Schemas.OrderShipping' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='CorrelationType' OID='e71072cc-8a27-4b64-ad74-1fe9ff856a2c' ParentLink='Module_CorrelationType' LowerBound='26.1' HigherBound='30.1'>
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='CustomerCorrelation' />
            <om:Property Name='Signal' Value='True' />
            <om:Element Type='PropertyRef' OID='7126d04b-b8b8-487c-82b5-c115691add23' ParentLink='CorrelationType_PropertyRef' LowerBound='28.9' HigherBound='28.27'>
                <om:Property Name='Ref' Value='Schemas.CustomerID' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='PropertyRef_1' />
                <om:Property Name='Signal' Value='False' />
            </om:Element>
        </om:Element>
        <om:Element Type='ServiceDeclaration' OID='2f43b1a7-c393-4142-8c5d-b47a8b603cce' ParentLink='Module_ServiceDeclaration' LowerBound='30.1' HigherBound='62.1'>
            <om:Property Name='InitializedTransactionType' Value='False' />
            <om:Property Name='IsInvokable' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='ParallelConvoy' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='ServiceBody' OID='7faedcbf-3fb3-4d52-ae91-37c48ec5255b' ParentLink='ServiceDeclaration_ServiceBody'>
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='Parallel' OID='30cc84ef-2e1e-47a7-b809-80a4b057e982' ParentLink='ServiceBody_Statement' LowerBound='42.1' HigherBound='60.1'>
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='ParallelActions_1' />
                    <om:Property Name='Signal' Value='False' />
                    <om:Element Type='ParallelBranch' OID='2cb55593-b162-4a54-adad-04df11300002' ParentLink='ReallyComplexStatement_Branch' LowerBound='47.1' HigherBound='51.1'>
                        <om:Property Name='IsGhostBranch' Value='True' />
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Name' Value='ParallelBranch_1' />
                        <om:Property Name='Signal' Value='False' />
                        <om:Element Type='Receive' OID='70b57a52-53e0-4fc3-aed7-7b90e4b965c5' ParentLink='ComplexStatement_Statement' LowerBound='47.1' HigherBound='49.1'>
                            <om:Property Name='Activate' Value='True' />
                            <om:Property Name='PortName' Value='InputPort' />
                            <om:Property Name='MessageName' Value='Billing' />
                            <om:Property Name='OperationName' Value='SubmitBilling' />
                            <om:Property Name='OperationMessageName' Value='Request' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='Receive_Billing' />
                            <om:Property Name='Signal' Value='True' />
                        </om:Element>
                        <om:Element Type='Send' OID='7ae6233a-d10a-43e8-b76d-2cc844d582d6' ParentLink='ComplexStatement_Statement' LowerBound='49.1' HigherBound='51.1'>
                            <om:Property Name='PortName' Value='AuditPort' />
                            <om:Property Name='MessageName' Value='Billing' />
                            <om:Property Name='OperationName' Value='auditBilling' />
                            <om:Property Name='OperationMessageName' Value='Request' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='Send_BillingAudit' />
                            <om:Property Name='Signal' Value='True' />
                        </om:Element>
                    </om:Element>
                    <om:Element Type='ParallelBranch' OID='c4e720a6-0823-45f5-88dc-a7131f5c9e5c' ParentLink='ReallyComplexStatement_Branch' LowerBound='54.1' HigherBound='58.1'>
                        <om:Property Name='IsGhostBranch' Value='True' />
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Name' Value='ParallelBranch_2' />
                        <om:Property Name='Signal' Value='False' />
                        <om:Element Type='Receive' OID='48a55ca1-25d7-496c-b257-d6f9c5ce0482' ParentLink='ComplexStatement_Statement' LowerBound='54.1' HigherBound='56.1'>
                            <om:Property Name='Activate' Value='True' />
                            <om:Property Name='PortName' Value='InputPort' />
                            <om:Property Name='MessageName' Value='Shipping' />
                            <om:Property Name='OperationName' Value='SubmitShipping' />
                            <om:Property Name='OperationMessageName' Value='Request' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='Receive_Shipping' />
                            <om:Property Name='Signal' Value='True' />
                        </om:Element>
                        <om:Element Type='Send' OID='ef311dbe-35d2-4349-b4ae-cf373a9fb317' ParentLink='ComplexStatement_Statement' LowerBound='56.1' HigherBound='58.1'>
                            <om:Property Name='PortName' Value='AuditPort' />
                            <om:Property Name='MessageName' Value='Shipping' />
                            <om:Property Name='OperationName' Value='auditshipping' />
                            <om:Property Name='OperationMessageName' Value='Request' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='Send_1' />
                            <om:Property Name='Signal' Value='True' />
                        </om:Element>
                    </om:Element>
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='69fa3375-0849-471c-bde2-b10cd3a5d841' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='33.1' HigherBound='35.1'>
                <om:Property Name='PortModifier' Value='Implements' />
                <om:Property Name='Orientation' Value='Left' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.InputPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='InputPort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='LogicalBindingAttribute' OID='4d6b04c3-55a4-4c8f-8e86-dd98472b692b' ParentLink='PortDeclaration_CLRAttribute' LowerBound='33.1' HigherBound='34.1'>
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='bac2f2f7-261b-4428-9e3c-1054052eddf5' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='35.1' HigherBound='37.1'>
                <om:Property Name='PortModifier' Value='Uses' />
                <om:Property Name='Orientation' Value='Right' />
                <om:Property Name='PortIndex' Value='13' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.AuditPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='AuditPort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='LogicalBindingAttribute' OID='29d238bc-ce96-4629-95d8-31afc5d63739' ParentLink='PortDeclaration_CLRAttribute' LowerBound='35.1' HigherBound='36.1'>
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='CorrelationDeclaration' OID='8d4772ae-640e-4257-93e3-ad391c057cc3' ParentLink='ServiceDeclaration_CorrelationDeclaration' LowerBound='37.1' HigherBound='38.1'>
                <om:Property Name='Type' Value='Orchestrations.CustomerCorrelation' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='CustomerCorrelationSet' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='StatementRef' OID='259bba34-22fa-44f0-8d90-d3a4b3c28d2a' ParentLink='CorrelationDeclaration_StatementRef' LowerBound='55.75' HigherBound='55.108'>
                    <om:Property Name='Initializes' Value='True' />
                    <om:Property Name='Ref' Value='48a55ca1-25d7-496c-b257-d6f9c5ce0482' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='StatementRef_1' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
                <om:Element Type='StatementRef' OID='459184bc-c07a-4018-8f36-30586f63eb98' ParentLink='CorrelationDeclaration_StatementRef' LowerBound='48.73' HigherBound='48.106'>
                    <om:Property Name='Initializes' Value='True' />
                    <om:Property Name='Ref' Value='70b57a52-53e0-4fc3-aed7-7b90e4b965c5' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='StatementRef_2' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='0c978c6a-eb59-4231-a12d-0fbed89448b6' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='38.1' HigherBound='39.1'>
                <om:Property Name='Type' Value='Schemas.OrderBilling' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Billing' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='ab87cdf9-04fe-4d04-82f6-2f719a0b8e7a' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='39.1' HigherBound='40.1'>
                <om:Property Name='Type' Value='Schemas.OrderShipping' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Shipping' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
        </om:Element>
    </om:Element>
</om:MetaModel>
";

        [System.SerializableAttribute]
        public class __ParallelConvoy_root_0 : Microsoft.XLANGs.Core.ServiceContext
        {
            public __ParallelConvoy_root_0(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "ParallelConvoy")
            {
            }

            public override int Index { get { return 0; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[0]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[0]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                ParallelConvoy __svc__ = (ParallelConvoy)_service;
                __ParallelConvoy_root_0 __ctx0__ = (__ParallelConvoy_root_0)(__svc__._stateMgrs[0]);

                if (__svc__.InputPort != null)
                {
                    __svc__.InputPort.Close(this, null);
                    __svc__.InputPort = null;
                }
                if (__svc__.AuditPort != null)
                {
                    __svc__.AuditPort.Close(this, null);
                    __svc__.AuditPort = null;
                }
                base.Finally();
            }

            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper0;
            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper1;
        }


        [System.SerializableAttribute]
        public class __ParallelConvoy_1 : Microsoft.XLANGs.Core.ExceptionHandlingContext
        {
            public __ParallelConvoy_1(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "ParallelConvoy")
            {
            }

            public override int Index { get { return 1; } }

            public override bool CombineParentCommit { get { return true; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[1]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[1]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                ParallelConvoy __svc__ = (ParallelConvoy)_service;
                __ParallelConvoy_1 __ctx1__ = (__ParallelConvoy_1)(__svc__._stateMgrs[1]);

                if (__ctx1__ != null && __ctx1__.__CustomerCorrelationSet != null)
                    __ctx1__.__CustomerCorrelationSet = null;
                if (__ctx1__ != null && __ctx1__.__Billing != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__Billing);
                    __ctx1__.__Billing = null;
                }
                if (__ctx1__ != null && __ctx1__.__Shipping != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__Shipping);
                    __ctx1__.__Shipping = null;
                }
                base.Finally();
            }

            [Microsoft.XLANGs.Core.UserVariableAttribute("Billing")]
            public __messagetype_Schemas_OrderBilling __Billing;
            [Microsoft.XLANGs.Core.UserVariableAttribute("Shipping")]
            public __messagetype_Schemas_OrderShipping __Shipping;
            [Microsoft.XLANGs.Core.UserVariableAttribute("CustomerCorrelationSet")]
            internal Microsoft.XLANGs.Core.Correlation __CustomerCorrelationSet;
        }

        private static Microsoft.XLANGs.Core.CorrelationType[] _correlationTypes = new Microsoft.XLANGs.Core.CorrelationType[] { new CustomerCorrelation() };
        public override Microsoft.XLANGs.Core.CorrelationType[] CorrelationTypes { get { return _correlationTypes; } }

        private static System.Guid[] _convoySetIds;

        public override System.Guid[] ConvoySetGuids
        {
            get { return _convoySetIds; }
            set { _convoySetIds = value; }
        }

        public static object[] StaticConvoySetInformation
        {
            get {
                return new object[] {
                    new Microsoft.XLANGs.Core.CorrelationType[] { _correlationTypes[0] }
                };
            }
        }

        [Microsoft.XLANGs.BaseTypes.LogicalBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("InputPort")]
        internal InputPortType InputPort;
        [Microsoft.XLANGs.BaseTypes.LogicalBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("AuditPort")]
        internal AuditPortType AuditPort;

        public static Microsoft.XLANGs.Core.PortInfo[] _portInfo = new Microsoft.XLANGs.Core.PortInfo[] {
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {InputPortType.SubmitBilling, InputPortType.SubmitShipping},
                                               typeof(ParallelConvoy).GetField("InputPort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.implements,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(ParallelConvoy), "InputPort"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {AuditPortType.auditBilling, AuditPortType.auditshipping},
                                               typeof(ParallelConvoy).GetField("AuditPort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.uses,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(ParallelConvoy), "AuditPort"),
                                               null)
        };

        public override Microsoft.XLANGs.Core.PortInfo[] PortInformation
        {
            get { return _portInfo; }
        }

        static public System.Collections.Hashtable PortsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[_portInfo[0].Name] = _portInfo[0];
                h[_portInfo[1].Name] = _portInfo[1];
                return h;
            }
        }

        public static System.Type[] InvokedServicesTypes
        {
            get
            {
                return new System.Type[] {
                    // type of each service invoked by this service
                };
            }
        }

        public static System.Type[] CalledServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static System.Type[] ExecedServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static object[] StaticSubscriptionsInformation {
            get {
                return new object[2]{
                     new object[5] { _portInfo[0], 0, null , 0, true }
                    , new object[5] { _portInfo[0], 1, null , 0, true }
                };
            }
        }

        public static Microsoft.XLANGs.RuntimeTypes.Location[] __eventLocations = new Microsoft.XLANGs.RuntimeTypes.Location[] {
            new Microsoft.XLANGs.RuntimeTypes.Location(0, "00000000-0000-0000-0000-000000000000", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(1, "30cc84ef-2e1e-47a7-b809-80a4b057e982", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(2, "30cc84ef-2e1e-47a7-b809-80a4b057e982", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(3, "70b57a52-53e0-4fc3-aed7-7b90e4b965c5", 2, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(4, "70b57a52-53e0-4fc3-aed7-7b90e4b965c5", 2, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(5, "7ae6233a-d10a-43e8-b76d-2cc844d582d6", 2, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(6, "7ae6233a-d10a-43e8-b76d-2cc844d582d6", 2, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(7, "48a55ca1-25d7-496c-b257-d6f9c5ce0482", 3, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(8, "48a55ca1-25d7-496c-b257-d6f9c5ce0482", 3, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(9, "ef311dbe-35d2-4349-b4ae-cf373a9fb317", 3, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(10, "ef311dbe-35d2-4349-b4ae-cf373a9fb317", 3, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(11, "00000000-0000-0000-0000-000000000000", 1, false)
        };

        public override Microsoft.XLANGs.RuntimeTypes.Location[] EventLocations
        {
            get { return __eventLocations; }
        }

        public static Microsoft.XLANGs.RuntimeTypes.EventData[] __eventData = new Microsoft.XLANGs.RuntimeTypes.EventData[] {
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Body),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Parallel),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Receive),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Send),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Parallel),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Body)
        };

        public static int[] __progressLocation0 = new int[] { 0,0,0,11,11,};
        public static int[] __progressLocation1 = new int[] { 0,0,1,3,2,2,11,11,11,11,};
        public static int[] __progressLocation2 = new int[] { 3,3,4,5,5,5,6,2,};
        public static int[] __progressLocation3 = new int[] { 7,7,8,9,9,9,10,2,};

        public static int[][] __progressLocations = new int[4] [] {__progressLocation0,__progressLocation1,__progressLocation2,__progressLocation3};
        public override int[][] ProgressLocations {get {return __progressLocations;} }

        public Microsoft.XLANGs.Core.StopConditions segment0(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[0];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[0];
            __ParallelConvoy_root_0 __ctx0__ = (__ParallelConvoy_root_0)_stateMgrs[0];
            __ParallelConvoy_1 __ctx1__ = (__ParallelConvoy_1)_stateMgrs[1];

            switch (__seg__.Progress)
            {
            case 0:
                InputPort = new InputPortType(0, this);
                AuditPort = new AuditPortType(1, this);
                __ctx__.PrologueCompleted = true;
                __ctx0__.__subWrapper0 = new Microsoft.XLANGs.Core.SubscriptionWrapper(ActivationSubGuids[0], InputPort, this);
                __ctx0__.__subWrapper1 = new Microsoft.XLANGs.Core.SubscriptionWrapper(ActivationSubGuids[1], InputPort, this);
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.Initialized) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.Initialized;
                goto case 1;
            case 1:
                __ctx1__ = new __ParallelConvoy_1(this);
                _stateMgrs[1] = __ctx1__;
                if ( !PostProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 2;
            case 2:
                __ctx0__.StartContext(__seg__, __ctx1__);
                if ( !PostProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                return Microsoft.XLANGs.Core.StopConditions.Blocked;
            case 3:
                if (!__ctx0__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                __ctx1__.Finally();
                ServiceDone(__seg__, (Microsoft.XLANGs.Core.Context)_stateMgrs[0]);
                __ctx0__.OnCommit();
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }

        public Microsoft.XLANGs.Core.StopConditions segment1(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[1];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[1];
            __ParallelConvoy_root_0 __ctx0__ = (__ParallelConvoy_root_0)_stateMgrs[0];
            __ParallelConvoy_1 __ctx1__ = (__ParallelConvoy_1)_stateMgrs[1];

            switch (__seg__.Progress)
            {
            case 0:
                __ctx__.PrologueCompleted = true;
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 1;
            case 1:
                if ( !PreProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[0],__eventData[0],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 2;
            case 2:
                if ( !PreProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[1],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 3;
            case 3:
                __ctx1__.__CustomerCorrelationSet = new Microsoft.XLANGs.Core.Correlation(this, 0, 0);
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                __seg__.RunSegments(new Microsoft.XLANGs.Core.Segment[] {_segments[2], _segments[3]}, this);
                if ( !PostProgressInc( __seg__, __ctx__, 5 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                return Microsoft.XLANGs.Core.StopConditions.Blocked;
            case 5:
                if ( !PreProgressInc( __seg__, __ctx__, 6 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                if (__ctx1__ != null && __ctx1__.__CustomerCorrelationSet != null)
                    __ctx1__.__CustomerCorrelationSet = null;
                if (AuditPort != null)
                {
                    AuditPort.Close(__ctx1__, __seg__);
                    AuditPort = null;
                }
                if (InputPort != null)
                {
                    InputPort.Close(__ctx1__, __seg__);
                    InputPort = null;
                }
                Tracker.FireEvent(__eventLocations[2],__eventData[4],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 6;
            case 6:
                if ( !PreProgressInc( __seg__, __ctx__, 7 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[11],__eventData[5],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 7;
            case 7:
                if (!__ctx1__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 8 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 8;
            case 8:
                if ( !PreProgressInc( __seg__, __ctx__, 9 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                __ctx1__.OnCommit();
                goto case 9;
            case 9:
                __seg__.SegmentDone();
                _segments[0].PredecessorDone(this);
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }

        public Microsoft.XLANGs.Core.StopConditions segment2(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Envelope __msgEnv__ = null;
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[2];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[1];
            __ParallelConvoy_root_0 __ctx0__ = (__ParallelConvoy_root_0)_stateMgrs[0];
            __ParallelConvoy_1 __ctx1__ = (__ParallelConvoy_1)_stateMgrs[1];

            switch (__seg__.Progress)
            {
            case 0:
                if ( !PreProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[3],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 1;
            case 1:
                if (!InputPort.GetMessageId(__ctx0__.__subWrapper0.getSubscription(this), __seg__, __ctx1__, out __msgEnv__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if (__ctx1__.__Billing != null)
                    __ctx1__.UnrefMessage(__ctx1__.__Billing);
                __ctx1__.__Billing = new __messagetype_Schemas_OrderBilling("Billing", __ctx1__);
                __ctx1__.RefMessage(__ctx1__.__Billing);
                InputPort.ReceiveMessage(0, __msgEnv__, __ctx1__.__Billing, new Microsoft.XLANGs.Core.Correlation[] { __ctx1__.__CustomerCorrelationSet }, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                if ( !PostProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 2;
            case 2:
                if ( !PreProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__Billing);
                    __edata.PortName = @"InputPort";
                    Tracker.FireEvent(__eventLocations[4],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 3;
            case 3:
                if ( !PreProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[5],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 4;
            case 4:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 5 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 5;
            case 5:
                if ( !PreProgressInc( __seg__, __ctx__, 6 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                AuditPort.SendMessage(0, __ctx1__.__Billing, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.None );
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 6;
            case 6:
                if ( !PreProgressInc( __seg__, __ctx__, 7 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__Billing);
                    __edata.PortName = @"AuditPort";
                    Tracker.FireEvent(__eventLocations[6],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__Billing != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__Billing);
                    __ctx1__.__Billing = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 7;
            case 7:
                __seg__.SegmentDone();
                _segments[1].PredecessorDone(this);
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }

        public Microsoft.XLANGs.Core.StopConditions segment3(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Envelope __msgEnv__ = null;
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[3];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[1];
            __ParallelConvoy_root_0 __ctx0__ = (__ParallelConvoy_root_0)_stateMgrs[0];
            __ParallelConvoy_1 __ctx1__ = (__ParallelConvoy_1)_stateMgrs[1];

            switch (__seg__.Progress)
            {
            case 0:
                if ( !PreProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[7],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 1;
            case 1:
                if (!InputPort.GetMessageId(__ctx0__.__subWrapper1.getSubscription(this), __seg__, __ctx1__, out __msgEnv__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if (__ctx1__.__Shipping != null)
                    __ctx1__.UnrefMessage(__ctx1__.__Shipping);
                __ctx1__.__Shipping = new __messagetype_Schemas_OrderShipping("Shipping", __ctx1__);
                __ctx1__.RefMessage(__ctx1__.__Shipping);
                InputPort.ReceiveMessage(1, __msgEnv__, __ctx1__.__Shipping, new Microsoft.XLANGs.Core.Correlation[] { __ctx1__.__CustomerCorrelationSet }, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                if ( !PostProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 2;
            case 2:
                if ( !PreProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__Shipping);
                    __edata.PortName = @"InputPort";
                    Tracker.FireEvent(__eventLocations[8],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 3;
            case 3:
                if ( !PreProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[9],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 4;
            case 4:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 5 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 5;
            case 5:
                if ( !PreProgressInc( __seg__, __ctx__, 6 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                AuditPort.SendMessage(1, __ctx1__.__Shipping, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.None );
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 6;
            case 6:
                if ( !PreProgressInc( __seg__, __ctx__, 7 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__Shipping);
                    __edata.PortName = @"AuditPort";
                    Tracker.FireEvent(__eventLocations[10],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__Shipping != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__Shipping);
                    __ctx1__.__Shipping = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 7;
            case 7:
                __seg__.SegmentDone();
                _segments[1].PredecessorDone(this);
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }
    }
    //#line 196 "C:\Northwind\demos\OrchII\ConvoySamples\Orchestrations\SequentialSample.odx"
    [Microsoft.XLANGs.BaseTypes.StaticConvoyAttribute(
        0,
        new System.Type[] { typeof(CustomerCorrelation) }
    )]
    [Microsoft.XLANGs.BaseTypes.StaticSubscriptionAttribute(
        0, "InputPortSeq", "SubmitBilling", -1, 0, true
    )]
    [Microsoft.XLANGs.BaseTypes.StaticSubscriptionAttribute(
        1, "InputPortSeq", "SubmitBilling", -1, 0, false
    )]
    [Microsoft.XLANGs.BaseTypes.StaticSubscriptionAttribute(
        2, "InputPortSeq", "SubmitShipping", -1, 0, false
    )]
    [Microsoft.XLANGs.BaseTypes.ServicePortsAttribute(
        new Microsoft.XLANGs.BaseTypes.EXLangSParameter[] {
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        },
        new System.Type[] {
            typeof(Orchestrations.InputPortType),
            typeof(Orchestrations.AuditPortType)
        },
        new System.String[] {
            "InputPortSeq",
            "AuditPortSeq"
        },
        new System.Type[] {
            null,
            null
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceCallTreeAttribute(
        new System.Type[] {
        },
        new System.Type[] {
        },
        new System.Type[] {
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal,
        Microsoft.XLANGs.BaseTypes.EXLangSServiceInfo.eNone
    )]
    [System.SerializableAttribute]
    [Microsoft.XLANGs.BaseTypes.BPELExportableAttribute(false)]
    sealed internal class SequentialSample : Microsoft.BizTalk.XLANGs.BTXEngine.BTXService
    {
        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        public static readonly bool __execable = false;
        [Microsoft.XLANGs.BaseTypes.CallCompensationAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSCallCompensationInfo.eNone,
            new System.String[] {
            },
            new System.String[] {
            }
        )]
        public static void __bodyProxy()
        {
        }
        private static System.Guid _serviceId = Microsoft.XLANGs.Core.HashHelper.HashServiceType(typeof(SequentialSample));
        private static volatile System.Guid[] _activationSubIds;

        private static new object _lockIdentity = new object();

        public static System.Guid UUID { get { return _serviceId; } }
        public override System.Guid ServiceId { get { return UUID; } }

        protected override System.Guid[] ActivationSubGuids
        {
            get { return _activationSubIds; }
            set { _activationSubIds = value; }
        }

        protected override object StaleStateLock
        {
            get { return _lockIdentity; }
        }

        protected override bool HasActivation { get { return true; } }

        internal bool IsExeced = false;

        static SequentialSample()
        {
            Microsoft.BizTalk.XLANGs.BTXEngine.BTXService.CacheStaticState( _serviceId );
        }

        private void ConstructorHelper()
        {
            _segments = new Microsoft.XLANGs.Core.Segment[] {
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment0), 0, 0, 0),
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment1), 1, 1, 1)
            };

            _Locks = 0;
            _rootContext = new __SequentialSample_root_0(this);
            _stateMgrs = new Microsoft.XLANGs.Core.IStateManager[2];
            _stateMgrs[0] = _rootContext;
            FinalConstruct();
        }

        public SequentialSample(System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXSession session, Microsoft.BizTalk.XLANGs.BTXEngine.BTXEvents tracker)
            : base(instanceId, session, "SequentialSample", tracker)
        {
            ConstructorHelper();
        }

        public SequentialSample(int callIndex, System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXService parent)
            : base(callIndex, instanceId, parent, "SequentialSample")
        {
            ConstructorHelper();
        }

        private const string _symInfo = @"
<XsymFile>
<ProcessFlow xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>      <shapeType>RootShape</shapeType>      <ShapeID>99940a06-5fb4-42a9-b010-ea2f78dbfd23</ShapeID>      
<children>                          
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>41d85325-897f-4ee0-84cb-41c6f0c5f56b</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Receive_InitialBill</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>30e33268-5e95-4a34-946c-06c483de6794</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>WhileShape</shapeType>      <ShapeID>c30fa5a7-60a1-4269-b8ea-dec845deb520</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Loop_1</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>ListenShape</shapeType>      <ShapeID>aa55f31c-4cf7-48ee-a5e3-53cd727b557f</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Listen_1</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>ListenBranchShape</shapeType>      <ShapeID>8de36ba5-6c55-40dc-8571-39adc0f78680</ShapeID>      <ParentLink>ReallyComplexStatement_Branch</ParentLink>                <shapeText>ListenBranch_1</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>ae8573a6-0432-4f01-a87d-6b623b4f2495</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Send_2</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>a865e8c3-6dbe-48fe-a5bc-79b9e9fca2aa</ShapeID>      <ParentLink>ListenBranch_Statement</ParentLink>                <shapeText>Receive_BillUpdates</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ListenBranchShape</shapeType>      <ShapeID>298f4d2e-0e45-485f-a0a3-57ed64c1b89e</ShapeID>      <ParentLink>ReallyComplexStatement_Branch</ParentLink>                <shapeText>ListenBranch_2</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>VariableAssignmentShape</shapeType>      <ShapeID>b9b7b6da-cac8-4ad8-ac43-5e0d93568ff1</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Expression_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>24f12668-5a1b-4399-95c8-bffc6934939e</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Send_3</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>78a1df7d-4508-4b31-b940-c9d0edbee932</ShapeID>      <ParentLink>ListenBranch_Statement</ParentLink>                <shapeText>Receive_Shipping</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                  </children>
  </ProcessFlow>
<Metadata>

<TrkMetadata>
<ActionName>'SequentialSample'</ActionName><IsAtomic>0</IsAtomic><Line>196</Line><Position>14</Position><ShapeID>'e211a116-cb8b-44e7-a052-0de295aa0001'</ShapeID>
</TrkMetadata>

<TrkMetadata>
<Line>210</Line><Position>22</Position><ShapeID>'41d85325-897f-4ee0-84cb-41c6f0c5f56b'</ShapeID>
<Messages>
	<MsgInfo><name>BillingMessage</name><part>part</part><schema>Schemas.OrderBilling</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>213</Line><Position>13</Position><ShapeID>'30e33268-5e95-4a34-946c-06c483de6794'</ShapeID>
<Messages>
	<MsgInfo><name>BillingMessage</name><part>part</part><schema>Schemas.OrderBilling</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>215</Line><Position>13</Position><ShapeID>'c30fa5a7-60a1-4269-b8ea-dec845deb520'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>219</Line><Position>17</Position><ShapeID>'aa55f31c-4cf7-48ee-a5e3-53cd727b557f'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>221</Line><Position>27</Position><ShapeID>'a865e8c3-6dbe-48fe-a5bc-79b9e9fca2aa'</ShapeID>
<Messages>
	<MsgInfo><name>BillingMessage</name><part>part</part><schema>Schemas.OrderBilling</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>227</Line><Position>27</Position><ShapeID>'78a1df7d-4508-4b31-b940-c9d0edbee932'</ShapeID>
<Messages>
	<MsgInfo><name>ShippingMessage</name><part>part</part><schema>Schemas.OrderShipping</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>224</Line><Position>25</Position><ShapeID>'ae8573a6-0432-4f01-a87d-6b623b4f2495'</ShapeID>
<Messages>
	<MsgInfo><name>BillingMessage</name><part>part</part><schema>Schemas.OrderBilling</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>230</Line><Position>34</Position><ShapeID>'b9b7b6da-cac8-4ad8-ac43-5e0d93568ff1'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>232</Line><Position>25</Position><ShapeID>'24f12668-5a1b-4399-95c8-bffc6934939e'</ShapeID>
<Messages>
	<MsgInfo><name>ShippingMessage</name><part>part</part><schema>Schemas.OrderShipping</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>
</Metadata>
</XsymFile>";

        public override string odXml { get { return _symODXML; } }

        private const string _symODXML = @"
<?xml version='1.0' encoding='utf-8' standalone='yes'?>
<om:MetaModel MajorVersion='1' MinorVersion='3' Core='2b131234-7959-458d-834f-2dc0769ce683' ScheduleModel='66366196-361d-448d-976f-cab5e87496d2' xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>
    <om:Element Type='Module' OID='f98518e8-b4c4-4b76-a486-7ccec4b0c82d' LowerBound='1.1' HigherBound='48.1'>
        <om:Property Name='ReportToAnalyst' Value='True' />
        <om:Property Name='Name' Value='Orchestrations' />
        <om:Property Name='Signal' Value='False' />
        <om:Element Type='ServiceDeclaration' OID='fe443629-378a-4fde-9c9f-407430e82c66' ParentLink='Module_ServiceDeclaration' LowerBound='4.1' HigherBound='47.1'>
            <om:Property Name='InitializedTransactionType' Value='False' />
            <om:Property Name='IsInvokable' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='SequentialSample' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='VariableDeclaration' OID='5f07c91a-0bac-4a4a-935e-dc57bed2b9f7' ParentLink='ServiceDeclaration_VariableDeclaration' LowerBound='15.1' HigherBound='16.1'>
                <om:Property Name='InitialValue' Value='true' />
                <om:Property Name='UseDefaultConstructor' Value='False' />
                <om:Property Name='Type' Value='System.Boolean' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='loopFlag' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='CorrelationDeclaration' OID='5fa4262f-1d72-4270-a0e7-94b2a5cb129f' ParentLink='ServiceDeclaration_CorrelationDeclaration' LowerBound='12.1' HigherBound='13.1'>
                <om:Property Name='Type' Value='Orchestrations.CustomerCorrelation' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='SeqCustomerCorrelation' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='StatementRef' OID='ae8ac86f-8ab6-4172-84df-a8879f24f06d' ParentLink='CorrelationDeclaration_StatementRef' LowerBound='19.75' HigherBound='19.108'>
                    <om:Property Name='Initializes' Value='True' />
                    <om:Property Name='Ref' Value='41d85325-897f-4ee0-84cb-41c6f0c5f56b' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='StatementRef_1' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
                <om:Element Type='StatementRef' OID='415aa0da-066a-4521-8016-310bfa9bfcd0' ParentLink='CorrelationDeclaration_StatementRef' LowerBound='30.80' HigherBound='30.102'>
                    <om:Property Name='Initializes' Value='False' />
                    <om:Property Name='Ref' Value='a865e8c3-6dbe-48fe-a5bc-79b9e9fca2aa' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='StatementRef_2' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
                <om:Element Type='StatementRef' OID='785ae218-0cd6-46bb-b6fd-795091fab10c' ParentLink='CorrelationDeclaration_StatementRef' LowerBound='36.82' HigherBound='36.104'>
                    <om:Property Name='Initializes' Value='False' />
                    <om:Property Name='Ref' Value='78a1df7d-4508-4b31-b940-c9d0edbee932' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='StatementRef_3' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='f042758c-40c4-49b4-8c6e-2dbfbce369a4' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='13.1' HigherBound='14.1'>
                <om:Property Name='Type' Value='Schemas.OrderBilling' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='BillingMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='375d6903-1658-4213-9df6-7c2360dd282c' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='14.1' HigherBound='15.1'>
                <om:Property Name='Type' Value='Schemas.OrderShipping' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='ShippingMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='ServiceBody' OID='99940a06-5fb4-42a9-b010-ea2f78dbfd23' ParentLink='ServiceDeclaration_ServiceBody'>
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='Receive' OID='41d85325-897f-4ee0-84cb-41c6f0c5f56b' ParentLink='ServiceBody_Statement' LowerBound='18.1' HigherBound='21.1'>
                    <om:Property Name='Activate' Value='True' />
                    <om:Property Name='PortName' Value='InputPortSeq' />
                    <om:Property Name='MessageName' Value='BillingMessage' />
                    <om:Property Name='OperationName' Value='SubmitBilling' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Receive_InitialBill' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Send' OID='30e33268-5e95-4a34-946c-06c483de6794' ParentLink='ServiceBody_Statement' LowerBound='21.1' HigherBound='23.1'>
                    <om:Property Name='PortName' Value='AuditPortSeq' />
                    <om:Property Name='MessageName' Value='BillingMessage' />
                    <om:Property Name='OperationName' Value='auditBilling' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_1' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='While' OID='c30fa5a7-60a1-4269-b8ea-dec845deb520' ParentLink='ServiceBody_Statement' LowerBound='23.1' HigherBound='45.1'>
                    <om:Property Name='Expression' Value='loopFlag' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Loop_1' />
                    <om:Property Name='Signal' Value='True' />
                    <om:Element Type='Listen' OID='aa55f31c-4cf7-48ee-a5e3-53cd727b557f' ParentLink='ComplexStatement_Statement' LowerBound='26.1' HigherBound='44.1'>
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Name' Value='Listen_1' />
                        <om:Property Name='Signal' Value='False' />
                        <om:Element Type='ListenBranch' OID='8de36ba5-6c55-40dc-8571-39adc0f78680' ParentLink='ReallyComplexStatement_Branch' LowerBound='26.1' HigherBound='26.1'>
                            <om:Property Name='IsGhostBranch' Value='True' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='ListenBranch_1' />
                            <om:Property Name='Signal' Value='True' />
                            <om:Element Type='Send' OID='ae8573a6-0432-4f01-a87d-6b623b4f2495' ParentLink='ComplexStatement_Statement' LowerBound='32.1' HigherBound='34.1'>
                                <om:Property Name='PortName' Value='AuditPortSeq' />
                                <om:Property Name='MessageName' Value='BillingMessage' />
                                <om:Property Name='OperationName' Value='auditBilling' />
                                <om:Property Name='OperationMessageName' Value='Request' />
                                <om:Property Name='ReportToAnalyst' Value='True' />
                                <om:Property Name='Name' Value='Send_2' />
                                <om:Property Name='Signal' Value='True' />
                            </om:Element>
                            <om:Element Type='Receive' OID='a865e8c3-6dbe-48fe-a5bc-79b9e9fca2aa' ParentLink='ListenBranch_Statement' LowerBound='29.1' HigherBound='30.103'>
                                <om:Property Name='Activate' Value='False' />
                                <om:Property Name='PortName' Value='InputPortSeq' />
                                <om:Property Name='MessageName' Value='BillingMessage' />
                                <om:Property Name='OperationName' Value='SubmitBilling' />
                                <om:Property Name='OperationMessageName' Value='Request' />
                                <om:Property Name='ReportToAnalyst' Value='True' />
                                <om:Property Name='Name' Value='Receive_BillUpdates' />
                                <om:Property Name='Signal' Value='True' />
                            </om:Element>
                        </om:Element>
                        <om:Element Type='ListenBranch' OID='298f4d2e-0e45-485f-a0a3-57ed64c1b89e' ParentLink='ReallyComplexStatement_Branch' LowerBound='26.1' HigherBound='26.1'>
                            <om:Property Name='IsGhostBranch' Value='True' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='ListenBranch_2' />
                            <om:Property Name='Signal' Value='True' />
                            <om:Element Type='VariableAssignment' OID='b9b7b6da-cac8-4ad8-ac43-5e0d93568ff1' ParentLink='ComplexStatement_Statement' LowerBound='38.1' HigherBound='40.1'>
                                <om:Property Name='Expression' Value='loopFlag = false;' />
                                <om:Property Name='ReportToAnalyst' Value='True' />
                                <om:Property Name='Name' Value='Expression_1' />
                                <om:Property Name='Signal' Value='True' />
                            </om:Element>
                            <om:Element Type='Send' OID='24f12668-5a1b-4399-95c8-bffc6934939e' ParentLink='ComplexStatement_Statement' LowerBound='40.1' HigherBound='42.1'>
                                <om:Property Name='PortName' Value='AuditPortSeq' />
                                <om:Property Name='MessageName' Value='ShippingMessage' />
                                <om:Property Name='OperationName' Value='auditshipping' />
                                <om:Property Name='OperationMessageName' Value='Request' />
                                <om:Property Name='ReportToAnalyst' Value='True' />
                                <om:Property Name='Name' Value='Send_3' />
                                <om:Property Name='Signal' Value='True' />
                            </om:Element>
                            <om:Element Type='Receive' OID='78a1df7d-4508-4b31-b940-c9d0edbee932' ParentLink='ListenBranch_Statement' LowerBound='35.1' HigherBound='36.105'>
                                <om:Property Name='Activate' Value='False' />
                                <om:Property Name='PortName' Value='InputPortSeq' />
                                <om:Property Name='MessageName' Value='ShippingMessage' />
                                <om:Property Name='OperationName' Value='SubmitShipping' />
                                <om:Property Name='OperationMessageName' Value='Request' />
                                <om:Property Name='ReportToAnalyst' Value='True' />
                                <om:Property Name='Name' Value='Receive_Shipping' />
                                <om:Property Name='Signal' Value='True' />
                            </om:Element>
                        </om:Element>
                    </om:Element>
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='7f460031-dabf-4383-b31e-f68627b4e3ca' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='7.1' HigherBound='10.1'>
                <om:Property Name='PortModifier' Value='Implements' />
                <om:Property Name='Orientation' Value='Left' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='True' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.InputPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='InputPortSeq' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='LogicalBindingAttribute' OID='4d907195-1c07-48c2-87eb-2b5ddeaa9674' ParentLink='PortDeclaration_CLRAttribute' LowerBound='7.1' HigherBound='8.1'>
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='f1f818aa-14d8-44a9-8617-2213b860597b' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='10.1' HigherBound='12.1'>
                <om:Property Name='PortModifier' Value='Uses' />
                <om:Property Name='Orientation' Value='Right' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.AuditPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='AuditPortSeq' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='LogicalBindingAttribute' OID='9bc755cc-a831-457a-b825-944d77d76431' ParentLink='PortDeclaration_CLRAttribute' LowerBound='10.1' HigherBound='11.1'>
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
    </om:Element>
</om:MetaModel>
";

        [System.SerializableAttribute]
        public class __SequentialSample_root_0 : Microsoft.XLANGs.Core.ServiceContext
        {
            public __SequentialSample_root_0(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "SequentialSample")
            {
            }

            public override int Index { get { return 0; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[0]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[0]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                SequentialSample __svc__ = (SequentialSample)_service;
                __SequentialSample_root_0 __ctx0__ = (__SequentialSample_root_0)(__svc__._stateMgrs[0]);

                if (__svc__.AuditPortSeq != null)
                {
                    __svc__.AuditPortSeq.Close(this, null);
                    __svc__.AuditPortSeq = null;
                }
                if (__svc__.InputPortSeq != null)
                {
                    __svc__.InputPortSeq.Close(this, null);
                    __svc__.InputPortSeq = null;
                }
                base.Finally();
            }

            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper0;
            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper1;
            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper2;
        }


        [System.SerializableAttribute]
        public class __SequentialSample_1 : Microsoft.XLANGs.Core.ExceptionHandlingContext
        {
            public __SequentialSample_1(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "SequentialSample")
            {
            }

            public override int Index { get { return 1; } }

            public override bool CombineParentCommit { get { return true; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[1]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[1]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                SequentialSample __svc__ = (SequentialSample)_service;
                __SequentialSample_1 __ctx1__ = (__SequentialSample_1)(__svc__._stateMgrs[1]);

                if (__ctx1__ != null && __ctx1__.__SeqCustomerCorrelation != null)
                    __ctx1__.__SeqCustomerCorrelation = null;
                if (__ctx1__ != null && __ctx1__.__BillingMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__BillingMessage);
                    __ctx1__.__BillingMessage = null;
                }
                if (__ctx1__ != null && __ctx1__.__ShippingMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__ShippingMessage);
                    __ctx1__.__ShippingMessage = null;
                }
                base.Finally();
            }

            [Microsoft.XLANGs.Core.UserVariableAttribute("BillingMessage")]
            public __messagetype_Schemas_OrderBilling __BillingMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("ShippingMessage")]
            public __messagetype_Schemas_OrderShipping __ShippingMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("SeqCustomerCorrelation")]
            internal Microsoft.XLANGs.Core.Correlation __SeqCustomerCorrelation;
            [Microsoft.XLANGs.Core.UserVariableAttribute("loopFlag")]
            internal System.Boolean __loopFlag;
        }

        private static Microsoft.XLANGs.Core.CorrelationType[] _correlationTypes = new Microsoft.XLANGs.Core.CorrelationType[] { new CustomerCorrelation() };
        public override Microsoft.XLANGs.Core.CorrelationType[] CorrelationTypes { get { return _correlationTypes; } }

        private static System.Guid[] _convoySetIds;

        public override System.Guid[] ConvoySetGuids
        {
            get { return _convoySetIds; }
            set { _convoySetIds = value; }
        }

        public static object[] StaticConvoySetInformation
        {
            get {
                return new object[] {
                    new Microsoft.XLANGs.Core.CorrelationType[] { _correlationTypes[0] }
                };
            }
        }

        [Microsoft.XLANGs.BaseTypes.LogicalBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.OrderedDeliveryAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("InputPortSeq")]
        internal InputPortType InputPortSeq;
        [Microsoft.XLANGs.BaseTypes.LogicalBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("AuditPortSeq")]
        internal AuditPortType AuditPortSeq;

        public static Microsoft.XLANGs.Core.PortInfo[] _portInfo = new Microsoft.XLANGs.Core.PortInfo[] {
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {InputPortType.SubmitBilling, InputPortType.SubmitShipping},
                                               typeof(SequentialSample).GetField("InputPortSeq", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.implements,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(SequentialSample), "InputPortSeq"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {AuditPortType.auditBilling, AuditPortType.auditshipping},
                                               typeof(SequentialSample).GetField("AuditPortSeq", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.uses,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(SequentialSample), "AuditPortSeq"),
                                               null)
        };

        public override Microsoft.XLANGs.Core.PortInfo[] PortInformation
        {
            get { return _portInfo; }
        }

        static public System.Collections.Hashtable PortsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[_portInfo[0].Name] = _portInfo[0];
                h[_portInfo[1].Name] = _portInfo[1];
                return h;
            }
        }

        public static System.Type[] InvokedServicesTypes
        {
            get
            {
                return new System.Type[] {
                    // type of each service invoked by this service
                };
            }
        }

        public static System.Type[] CalledServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static System.Type[] ExecedServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static object[] StaticSubscriptionsInformation {
            get {
                return new object[3]{
                     new object[5] { _portInfo[0], 0, null , 0, true }
                    , new object[5] { _portInfo[0], 0, null , 0, false }
                    , new object[5] { _portInfo[0], 1, null , 0, false }
                };
            }
        }

        public static Microsoft.XLANGs.RuntimeTypes.Location[] __eventLocations = new Microsoft.XLANGs.RuntimeTypes.Location[] {
            new Microsoft.XLANGs.RuntimeTypes.Location(0, "00000000-0000-0000-0000-000000000000", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(1, "41d85325-897f-4ee0-84cb-41c6f0c5f56b", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(2, "41d85325-897f-4ee0-84cb-41c6f0c5f56b", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(3, "00000000-0000-0000-0000-000000000000", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(4, "30e33268-5e95-4a34-946c-06c483de6794", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(5, "30e33268-5e95-4a34-946c-06c483de6794", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(6, "c30fa5a7-60a1-4269-b8ea-dec845deb520", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(7, "aa55f31c-4cf7-48ee-a5e3-53cd727b557f", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(8, "a865e8c3-6dbe-48fe-a5bc-79b9e9fca2aa", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(9, "a865e8c3-6dbe-48fe-a5bc-79b9e9fca2aa", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(10, "ae8573a6-0432-4f01-a87d-6b623b4f2495", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(11, "ae8573a6-0432-4f01-a87d-6b623b4f2495", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(12, "78a1df7d-4508-4b31-b940-c9d0edbee932", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(13, "78a1df7d-4508-4b31-b940-c9d0edbee932", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(14, "b9b7b6da-cac8-4ad8-ac43-5e0d93568ff1", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(15, "b9b7b6da-cac8-4ad8-ac43-5e0d93568ff1", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(16, "24f12668-5a1b-4399-95c8-bffc6934939e", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(17, "24f12668-5a1b-4399-95c8-bffc6934939e", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(18, "aa55f31c-4cf7-48ee-a5e3-53cd727b557f", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(19, "c30fa5a7-60a1-4269-b8ea-dec845deb520", 1, false)
        };

        public override Microsoft.XLANGs.RuntimeTypes.Location[] EventLocations
        {
            get { return __eventLocations; }
        }

        public static Microsoft.XLANGs.RuntimeTypes.EventData[] __eventData = new Microsoft.XLANGs.RuntimeTypes.EventData[] {
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Body),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Receive),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Send),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.WhileBody),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.While),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Listen),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Expression),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Expression),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Listen),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.While),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.WhileBody),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Body)
        };

        public static int[] __progressLocation0 = new int[] { 0,0,0,3,3,};
        public static int[] __progressLocation1 = new int[] { 0,0,1,1,2,2,4,4,4,5,6,6,6,7,7,8,9,10,10,10,11,7,12,13,14,14,15,16,16,16,17,7,18,19,19,19,3,3,3,3,};

        public static int[][] __progressLocations = new int[2] [] {__progressLocation0,__progressLocation1};
        public override int[][] ProgressLocations {get {return __progressLocations;} }

        public Microsoft.XLANGs.Core.StopConditions segment0(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[0];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[0];
            __SequentialSample_1 __ctx1__ = (__SequentialSample_1)_stateMgrs[1];
            __SequentialSample_root_0 __ctx0__ = (__SequentialSample_root_0)_stateMgrs[0];

            switch (__seg__.Progress)
            {
            case 0:
                InputPortSeq = new InputPortType(0, this);
                AuditPortSeq = new AuditPortType(1, this);
                __ctx__.PrologueCompleted = true;
                __ctx0__.__subWrapper0 = new Microsoft.XLANGs.Core.SubscriptionWrapper(ActivationSubGuids[0], InputPortSeq, this);
                __ctx0__.__subWrapper1 = new Microsoft.XLANGs.Core.SubscriptionWrapper(ActivationSubGuids[1], InputPortSeq, this);
                __ctx0__.__subWrapper2 = new Microsoft.XLANGs.Core.SubscriptionWrapper(ActivationSubGuids[2], InputPortSeq, this);
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.Initialized) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.Initialized;
                goto case 1;
            case 1:
                __ctx1__ = new __SequentialSample_1(this);
                _stateMgrs[1] = __ctx1__;
                if ( !PostProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 2;
            case 2:
                __ctx0__.StartContext(__seg__, __ctx1__);
                if ( !PostProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                return Microsoft.XLANGs.Core.StopConditions.Blocked;
            case 3:
                if (!__ctx0__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                __ctx1__.Finally();
                ServiceDone(__seg__, (Microsoft.XLANGs.Core.Context)_stateMgrs[0]);
                __ctx0__.OnCommit();
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }

        public Microsoft.XLANGs.Core.StopConditions segment1(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Envelope __msgEnv__ = null;
            bool __condition__;
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[1];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[1];
            __SequentialSample_1 __ctx1__ = (__SequentialSample_1)_stateMgrs[1];
            __SequentialSample_root_0 __ctx0__ = (__SequentialSample_root_0)_stateMgrs[0];

            switch (__seg__.Progress)
            {
            case 0:
                __ctx1__.__loopFlag = default(System.Boolean);
                __ctx__.PrologueCompleted = true;
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 1;
            case 1:
                if ( !PreProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[0],__eventData[0],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 2;
            case 2:
                if ( !PreProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                __ctx1__.__SeqCustomerCorrelation = new Microsoft.XLANGs.Core.Correlation(this, 0, 0);
                Tracker.FireEvent(__eventLocations[1],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 3;
            case 3:
                if (!InputPortSeq.GetMessageId(__ctx0__.__subWrapper0.getSubscription(this), __seg__, __ctx1__, out __msgEnv__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if (__ctx1__.__BillingMessage != null)
                    __ctx1__.UnrefMessage(__ctx1__.__BillingMessage);
                __ctx1__.__BillingMessage = new __messagetype_Schemas_OrderBilling("BillingMessage", __ctx1__);
                __ctx1__.RefMessage(__ctx1__.__BillingMessage);
                InputPortSeq.ReceiveMessage(0, __msgEnv__, __ctx1__.__BillingMessage, new Microsoft.XLANGs.Core.Correlation[] { __ctx1__.__SeqCustomerCorrelation }, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                if ( !PreProgressInc( __seg__, __ctx__, 5 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__BillingMessage);
                    __edata.PortName = @"InputPortSeq";
                    Tracker.FireEvent(__eventLocations[2],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 5;
            case 5:
                __ctx1__.__loopFlag = true;
                if ( !PostProgressInc( __seg__, __ctx__, 6 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 6;
            case 6:
                if ( !PreProgressInc( __seg__, __ctx__, 7 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[4],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 7;
            case 7:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 8 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 8;
            case 8:
                if ( !PreProgressInc( __seg__, __ctx__, 9 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                AuditPortSeq.SendMessage(0, __ctx1__.__BillingMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.None );
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 9;
            case 9:
                if ( !PreProgressInc( __seg__, __ctx__, 10 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__BillingMessage);
                    __edata.PortName = @"AuditPortSeq";
                    Tracker.FireEvent(__eventLocations[5],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 10;
            case 10:
                if ( !PreProgressInc( __seg__, __ctx__, 11 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[6],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 11;
            case 11:
                __condition__ = __ctx1__.__loopFlag;
                if (!__condition__)
                {
                    if ( !PostProgressInc( __seg__, __ctx__, 35 ) )
                        return Microsoft.XLANGs.Core.StopConditions.Paused;
                    goto case 35;
                }
                if ( !PostProgressInc( __seg__, __ctx__, 12 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 12;
            case 12:
                if ( !PreProgressInc( __seg__, __ctx__, 13 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[6],__eventData[4],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 13;
            case 13:
                if ( !PreProgressInc( __seg__, __ctx__, 14 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[7],__eventData[5],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 14;
            case 14:
                {
                    int idx = Microsoft.XLANGs.Core.PortBase.ListenForMessageId(new Microsoft.XLANGs.Core.Subscription[] { __ctx0__.__subWrapper1.getSubscription(this), __ctx0__.__subWrapper2.getSubscription(this) }, __seg__, __ctx1__, out __msgEnv__ , _locations[0]);
                    if (idx < 0) {
                        return Microsoft.XLANGs.Core.StopConditions.Blocked;
                    }
                    else if (idx == 0) {
                        if (__ctx1__.__BillingMessage != null)
                            __ctx1__.UnrefMessage(__ctx1__.__BillingMessage);
                        __ctx1__.__BillingMessage = new __messagetype_Schemas_OrderBilling("BillingMessage", __ctx1__);
                        __ctx1__.RefMessage(__ctx1__.__BillingMessage);
                        InputPortSeq.ReceiveMessage(0, __msgEnv__, __ctx1__.__BillingMessage, null, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                        if ( !PostProgressInc( __seg__, __ctx__, 15 ) )
                            return Microsoft.XLANGs.Core.StopConditions.Paused;
                        goto case 15;
                    }
                    else if (idx == 1) {
                        if (__ctx1__.__ShippingMessage != null)
                            __ctx1__.UnrefMessage(__ctx1__.__ShippingMessage);
                        __ctx1__.__ShippingMessage = new __messagetype_Schemas_OrderShipping("ShippingMessage", __ctx1__);
                        __ctx1__.RefMessage(__ctx1__.__ShippingMessage);
                        InputPortSeq.ReceiveMessage(1, __msgEnv__, __ctx1__.__ShippingMessage, null, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                        if ( !PostProgressInc( __seg__, __ctx__, 22 ) )
                            return Microsoft.XLANGs.Core.StopConditions.Paused;
                        goto case 22;
                    }
                }
                break;
            case 15:
                if ( !PreProgressInc( __seg__, __ctx__, 16 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[8],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 16;
            case 16:
                if ( !PreProgressInc( __seg__, __ctx__, 17 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__BillingMessage);
                    __edata.PortName = @"InputPortSeq";
                    Tracker.FireEvent(__eventLocations[9],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 17;
            case 17:
                if ( !PreProgressInc( __seg__, __ctx__, 18 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[10],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 18;
            case 18:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 19 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 19;
            case 19:
                if ( !PreProgressInc( __seg__, __ctx__, 20 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                AuditPortSeq.SendMessage(0, __ctx1__.__BillingMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.None );
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 20;
            case 20:
                if ( !PreProgressInc( __seg__, __ctx__, 21 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__BillingMessage);
                    __edata.PortName = @"AuditPortSeq";
                    Tracker.FireEvent(__eventLocations[11],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 21;
            case 21:
                if ( !PostProgressInc( __seg__, __ctx__, 32 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 32;
            case 22:
                if ( !PreProgressInc( __seg__, __ctx__, 23 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[12],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 23;
            case 23:
                if ( !PreProgressInc( __seg__, __ctx__, 24 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__ShippingMessage);
                    __edata.PortName = @"InputPortSeq";
                    Tracker.FireEvent(__eventLocations[13],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 24;
            case 24:
                if ( !PreProgressInc( __seg__, __ctx__, 25 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[14],__eventData[6],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 25;
            case 25:
                __ctx1__.__loopFlag = false;
                if ( !PostProgressInc( __seg__, __ctx__, 26 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 26;
            case 26:
                if ( !PreProgressInc( __seg__, __ctx__, 27 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[15],__eventData[7],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 27;
            case 27:
                if ( !PreProgressInc( __seg__, __ctx__, 28 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[16],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 28;
            case 28:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 29 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 29;
            case 29:
                if ( !PreProgressInc( __seg__, __ctx__, 30 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                AuditPortSeq.SendMessage(1, __ctx1__.__ShippingMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.None );
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 30;
            case 30:
                if ( !PreProgressInc( __seg__, __ctx__, 31 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__ShippingMessage);
                    __edata.PortName = @"AuditPortSeq";
                    Tracker.FireEvent(__eventLocations[17],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 31;
            case 31:
                if ( !PostProgressInc( __seg__, __ctx__, 32 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 32;
            case 32:
                if ( !PreProgressInc( __seg__, __ctx__, 33 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                if (__ctx1__ != null && __ctx1__.__ShippingMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__ShippingMessage);
                    __ctx1__.__ShippingMessage = null;
                }
                Tracker.FireEvent(__eventLocations[18],__eventData[8],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 33;
            case 33:
                if ( !PreProgressInc( __seg__, __ctx__, 34 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[19],__eventData[9],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 34;
            case 34:
                if ( !PostProgressInc( __seg__, __ctx__, 11 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 11;
            case 35:
                if ( !PreProgressInc( __seg__, __ctx__, 36 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                if (__ctx1__ != null && __ctx1__.__SeqCustomerCorrelation != null)
                    __ctx1__.__SeqCustomerCorrelation = null;
                if (__ctx1__ != null && __ctx1__.__BillingMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__BillingMessage);
                    __ctx1__.__BillingMessage = null;
                }
                if (AuditPortSeq != null)
                {
                    AuditPortSeq.Close(__ctx1__, __seg__);
                    AuditPortSeq = null;
                }
                if (InputPortSeq != null)
                {
                    InputPortSeq.Close(__ctx1__, __seg__);
                    InputPortSeq = null;
                }
                Tracker.FireEvent(__eventLocations[19],__eventData[10],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 36;
            case 36:
                if ( !PreProgressInc( __seg__, __ctx__, 37 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[3],__eventData[11],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 37;
            case 37:
                if (!__ctx1__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 38 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 38;
            case 38:
                if ( !PreProgressInc( __seg__, __ctx__, 39 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                __ctx1__.OnCommit();
                goto case 39;
            case 39:
                __seg__.SegmentDone();
                _segments[0].PredecessorDone(this);
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }
        private static Microsoft.XLANGs.Core.CachedObject[] _locations = new Microsoft.XLANGs.Core.CachedObject[] {
            new Microsoft.XLANGs.Core.CachedObject(new System.Guid("{C4519CB8-B772-47F4-9D87-A0E11E807779}"))
        };

    }

    [System.SerializableAttribute]
    sealed public class __Schemas_OrderBilling__ : Microsoft.XLANGs.Core.XSDPart
    {
        private static Schemas.OrderBilling _schema = new Schemas.OrderBilling();

        public __Schemas_OrderBilling__(Microsoft.XLANGs.Core.XMessage msg, string name, int index) : base(msg, name, index) { }

        
        #region part reflection support
        public static Microsoft.XLANGs.BaseTypes.SchemaBase PartSchema { get { return (Microsoft.XLANGs.BaseTypes.SchemaBase)_schema; } }
        #endregion // part reflection support
    }

    [Microsoft.XLANGs.BaseTypes.MessageTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic,
        Microsoft.XLANGs.BaseTypes.EXLangSMessageInfo.eThirdKind,
        "Schemas.OrderBilling",
        new System.Type[]{
            typeof(Schemas.OrderBilling)
        },
        new string[]{
            "part"
        },
        new System.Type[]{
            typeof(__Schemas_OrderBilling__)
        },
        0,
        @"http://Northwind.com/abts/billing#OrderBilling"
    )]
    [System.SerializableAttribute]
    sealed public class __messagetype_Schemas_OrderBilling : Microsoft.BizTalk.XLANGs.BTXEngine.BTXMessage
    {
        public __Schemas_OrderBilling__ part;

        private void __CreatePartWrappers()
        {
            part = new __Schemas_OrderBilling__(this, "part", 0);
            this.AddPart("part", 0, part);
        }

        public __messagetype_Schemas_OrderBilling(string msgName, Microsoft.XLANGs.Core.Context ctx) : base(msgName, ctx)
        {
            __CreatePartWrappers();
        }
    }

    [System.SerializableAttribute]
    sealed public class __Schemas_OrderShipping__ : Microsoft.XLANGs.Core.XSDPart
    {
        private static Schemas.OrderShipping _schema = new Schemas.OrderShipping();

        public __Schemas_OrderShipping__(Microsoft.XLANGs.Core.XMessage msg, string name, int index) : base(msg, name, index) { }

        
        #region part reflection support
        public static Microsoft.XLANGs.BaseTypes.SchemaBase PartSchema { get { return (Microsoft.XLANGs.BaseTypes.SchemaBase)_schema; } }
        #endregion // part reflection support
    }

    [Microsoft.XLANGs.BaseTypes.MessageTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic,
        Microsoft.XLANGs.BaseTypes.EXLangSMessageInfo.eThirdKind,
        "Schemas.OrderShipping",
        new System.Type[]{
            typeof(Schemas.OrderShipping)
        },
        new string[]{
            "part"
        },
        new System.Type[]{
            typeof(__Schemas_OrderShipping__)
        },
        0,
        @"http://Northwind.com/abts/ordershipment#OrderShipping"
    )]
    [System.SerializableAttribute]
    sealed public class __messagetype_Schemas_OrderShipping : Microsoft.BizTalk.XLANGs.BTXEngine.BTXMessage
    {
        public __Schemas_OrderShipping__ part;

        private void __CreatePartWrappers()
        {
            part = new __Schemas_OrderShipping__(this, "part", 0);
            this.AddPart("part", 0, part);
        }

        public __messagetype_Schemas_OrderShipping(string msgName, Microsoft.XLANGs.Core.Context ctx) : base(msgName, ctx)
        {
            __CreatePartWrappers();
        }
    }

    [Microsoft.XLANGs.BaseTypes.BPELExportableAttribute(false)]
    sealed public class _MODULE_PROXY_ { }
}
