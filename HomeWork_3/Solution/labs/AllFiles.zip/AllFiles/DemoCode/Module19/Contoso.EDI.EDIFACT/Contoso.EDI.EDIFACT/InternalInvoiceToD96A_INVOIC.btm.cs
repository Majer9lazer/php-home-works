namespace Contoso.EDI.EDIFACT {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Contoso.Schemas.Internal.InternalInvoice", typeof(global::Contoso.Schemas.Internal.InternalInvoice))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Contoso.EDI.EDIFACT.EFACT_D96A_INVOIC", typeof(global::Contoso.EDI.EDIFACT.EFACT_D96A_INVOIC))]
    public sealed class InternalInvoiceToD96A_INVOIC : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp"" version=""1.0"" xmlns:s0=""http://Contoso.Schemas.Internal.InternalInvoice"" xmlns:ns0=""http://schemas.microsoft.com/BizTalk/EDI/EDIFACT/2006"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:Invoice"" />
  </xsl:template>
  <xsl:template match=""/s0:Invoice"">
    <xsl:variable name=""var:v2"" select=""string(Date/text())"" />
    <xsl:variable name=""var:v4"" select=""'79'"" />
    <xsl:variable name=""var:v5"" select=""Sum"" />
    <xsl:variable name=""var:v6"" select=""'124'"" />
    <xsl:variable name=""var:v7"" select=""TaxTotal"" />
    <xsl:variable name=""var:v8"" select=""'128'"" />
    <xsl:variable name=""var:v9"" select=""Total"" />
    <ns0:EFACT_D96A_INVOIC>
      <UNH>
        <UNH1>
          <xsl:text>UNH1</xsl:text>
        </UNH1>
        <UNH2>
          <UNH2.1>
            <xsl:text>INVOIC</xsl:text>
          </UNH2.1>
          <UNH2.2>
            <xsl:text>D</xsl:text>
          </UNH2.2>
          <UNH2.3>
            <xsl:text>96A</xsl:text>
          </UNH2.3>
          <UNH2.4>
            <xsl:text>UN</xsl:text>
          </UNH2.4>
        </UNH2>
      </UNH>
      <ns0:BGM>
        <BGM02>
          <xsl:value-of select=""ID/text()"" />
        </BGM02>
        <BGM03>
          <xsl:text>9</xsl:text>
        </BGM03>
      </ns0:BGM>
      <ns0:DTM>
        <ns0:C507>
          <C50701>
            <xsl:text>3</xsl:text>
          </C50701>
          <xsl:variable name=""var:v1"" select=""userCSharp:FormatEDIDate(string(Date/text()))"" />
          <C50702>
            <xsl:value-of select=""$var:v1"" />
          </C50702>
        </ns0:C507>
      </ns0:DTM>
      <ns0:RFFLoop1>
        <ns0:RFF>
          <ns0:C506>
            <C50601>
              <xsl:text>ON</xsl:text>
            </C50601>
            <C50602>
              <xsl:value-of select=""OrderNum/text()"" />
            </C50602>
          </ns0:C506>
        </ns0:RFF>
        <ns0:DTM_2>
          <ns0:C507_2>
            <C50701>
              <xsl:text>3</xsl:text>
            </C50701>
            <xsl:variable name=""var:v3"" select=""userCSharp:FormatEDIDate($var:v2)"" />
            <C50702>
              <xsl:value-of select=""$var:v3"" />
            </C50702>
          </ns0:C507_2>
        </ns0:DTM_2>
      </ns0:RFFLoop1>
      <ns0:NADLoop1>
        <ns0:NAD>
          <NAD01>
            <xsl:text>SE</xsl:text>
          </NAD01>
          <ns0:C082>
            <C08201>
              <xsl:value-of select=""Us/Name/text()"" />
            </C08201>
          </ns0:C082>
          <ns0:C058>
            <C05801>
              <xsl:value-of select=""Us/Address/text()"" />
            </C05801>
          </ns0:C058>
          <NAD06>
            <xsl:value-of select=""Us/City/text()"" />
          </NAD06>
          <NAD07>
            <xsl:value-of select=""Us/State/text()"" />
          </NAD07>
          <NAD08>
            <xsl:value-of select=""Us/Postal/text()"" />
          </NAD08>
          <NAD09>
            <xsl:value-of select=""Us/Country/text()"" />
          </NAD09>
        </ns0:NAD>
      </ns0:NADLoop1>
      <ns0:NADLoop1>
        <ns0:NAD>
          <NAD01>
            <xsl:text>SE</xsl:text>
          </NAD01>
          <ns0:C082>
            <C08201>
              <xsl:value-of select=""Them/Name/text()"" />
            </C08201>
          </ns0:C082>
          <ns0:C058>
            <C05801>
              <xsl:value-of select=""Them/Address/text()"" />
            </C05801>
          </ns0:C058>
          <NAD06>
            <xsl:value-of select=""Them/City/text()"" />
          </NAD06>
          <NAD07>
            <xsl:value-of select=""Them/State/text()"" />
          </NAD07>
          <NAD08>
            <xsl:value-of select=""Them/Postal/text()"" />
          </NAD08>
          <NAD09>
            <xsl:value-of select=""Them/Country/text()"" />
          </NAD09>
        </ns0:NAD>
      </ns0:NADLoop1>
      <ns0:TAXLoop1>
        <ns0:TAX>
          <TAX01>
            <xsl:text>7</xsl:text>
          </TAX01>
          <ns0:C241>
            <C24101>
              <xsl:text>VAT</xsl:text>
            </C24101>
          </ns0:C241>
          <TAX04>
            <xsl:value-of select=""TaxPercent/text()"" />
          </TAX04>
        </ns0:TAX>
      </ns0:TAXLoop1>
      <xsl:for-each select=""Items/Item"">
        <ns0:LINLoop1>
          <ns0:LIN>
            <LIN01>
              <xsl:value-of select=""ItemNum/text()"" />
            </LIN01>
            <ns0:C212>
              <C21201>
                <xsl:value-of select=""ItemId/text()"" />
              </C21201>
            </ns0:C212>
          </ns0:LIN>
          <ns0:IMD_2>
            <ns0:C273_2>
              <C27304>
                <xsl:value-of select=""ItemDescription/text()"" />
              </C27304>
            </ns0:C273_2>
          </ns0:IMD_2>
          <ns0:QTY_2>
            <ns0:C186_2>
              <C18601>
                <xsl:text>47</xsl:text>
              </C18601>
              <C18602>
                <xsl:value-of select=""Count/text()"" />
              </C18602>
            </ns0:C186_2>
          </ns0:QTY_2>
          <ns0:MOALoop2>
            <ns0:MOA_5>
              <ns0:C516_5>
                <C51601>
                  <xsl:text>66</xsl:text>
                </C51601>
                <C51602>
                  <xsl:value-of select=""ItemPrice/text()"" />
                </C51602>
              </ns0:C516_5>
            </ns0:MOA_5>
          </ns0:MOALoop2>
          <ns0:PRILoop1>
            <ns0:PRI>
              <ns0:C509>
                <C50901>
                  <xsl:text>AAA</xsl:text>
                </C50901>
                <C50902>
                  <xsl:value-of select=""ItemTotal/text()"" />
                </C50902>
              </ns0:C509>
            </ns0:PRI>
          </ns0:PRILoop1>
          <xsl:value-of select=""./text()"" />
        </ns0:LINLoop1>
      </xsl:for-each>
      <ns0:UNS>
        <UNS01>
          <xsl:text>S</xsl:text>
        </UNS01>
      </ns0:UNS>
      <ns0:MOALoop4>
        <ns0:MOA_10>
          <ns0:C516_10>
            <C51601>
              <xsl:value-of select=""$var:v4"" />
            </C51601>
            <C51602>
              <xsl:value-of select=""$var:v5"" />
            </C51602>
          </ns0:C516_10>
        </ns0:MOA_10>
      </ns0:MOALoop4>
      <ns0:MOALoop4>
        <ns0:MOA_10>
          <ns0:C516_10>
            <C51601>
              <xsl:value-of select=""$var:v6"" />
            </C51601>
            <C51602>
              <xsl:value-of select=""$var:v7"" />
            </C51602>
          </ns0:C516_10>
        </ns0:MOA_10>
      </ns0:MOALoop4>
      <ns0:MOALoop4>
        <ns0:MOA_10>
          <ns0:C516_10>
            <C51601>
              <xsl:value-of select=""$var:v8"" />
            </C51601>
            <C51602>
              <xsl:value-of select=""$var:v9"" />
            </C51602>
          </ns0:C516_10>
        </ns0:MOA_10>
      </ns0:MOALoop4>
    </ns0:EFACT_D96A_INVOIC>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string FormatEDIDate(string date)
{
System.DateTime dt = System.DateTime.Parse(date);
return dt.ToString(""yyyyMMdd"");
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Contoso.Schemas.Internal.InternalInvoice";
        
        private const global::Contoso.Schemas.Internal.InternalInvoice _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Contoso.EDI.EDIFACT.EFACT_D96A_INVOIC";
        
        private const global::Contoso.EDI.EDIFACT.EFACT_D96A_INVOIC _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Contoso.Schemas.Internal.InternalInvoice";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Contoso.EDI.EDIFACT.EFACT_D96A_INVOIC";
                return _TrgSchemas;
            }
        }
    }
}
