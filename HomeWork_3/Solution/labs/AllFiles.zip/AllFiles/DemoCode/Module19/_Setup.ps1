. ..\scripts\Functions.ps1

Get-ScriptDirectory | set-location

RemoveBTSApplication Demos.Northwind

RemoveBTSApplication BAMInterceptors




