/// -----------------------------------------------------------------------------------------------------------
/// Module      :  NorthwindLOBAdapterMetadataSearchHandler.cs
/// Description :  This class is used for performing a connection-based search for metadata from the target system
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;

using System.Linq;

#endregion

namespace Northwind.LOB
{
    public class NorthwindLOBAdapterMetadataSearchHandler : NorthwindLOBAdapterHandlerBase, IMetadataSearchHandler
    {
        /// <summary>
        /// Initializes a new instance of the NorthwindLOBAdapterMetadataSearchHandler class
        /// </summary>
        public NorthwindLOBAdapterMetadataSearchHandler(NorthwindLOBAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IMetadataSearchHandler Members

        /// <summary>
        /// Retrieves an array of MetadataRetrievalNodes (see Microsoft.ServiceModel.Channels) from the target system.
        /// The search will begin at the path provided in absoluteName, which points to a location in the tree of metadata nodes.
        /// The contents of the array are filtered by SearchCriteria and the number of nodes returned is limited by maxChildNodes.
        /// The method should complete within the specified timespan or throw a timeout exception.  If absoluteName is null or an empty string, return nodes starting from the root.
        /// If SearchCriteria is null or an empty string, return all nodes.
        /// </summary>
        public MetadataRetrievalNode[] Search(string nodeId
            , string searchCriteria
            , int maxChildNodes, TimeSpan timeout)
        {
            switch (nodeId)
            {
                case "discounts":
                    return GetDiscountNodes();
                case "surcharges":
                    return GetSurchargeNodes();
                default:
                    return GetDiscountNodes().Union(GetSurchargeNodes()).ToArray();
            }
        }

        #endregion IMetadataSearchHandler Members

        private MetadataRetrievalNode[] GetSurchargeNodes()
        {
            MetadataRetrievalNode surchargeNode = new MetadataRetrievalNode
            {
                NodeId = "getSurcharges",
                DisplayName = "List Surcharges",
                Description = "Provides listings of surcharges",
                Direction = MetadataRetrievalNodeDirections.Outbound,
                IsOperation = true
            };

            return new MetadataRetrievalNode[] { surchargeNode };
        }

        private MetadataRetrievalNode[] GetDiscountNodes()
        {
            MetadataRetrievalNode discountNode = new MetadataRetrievalNode
            {
                NodeId = "getDiscounts",
                DisplayName = "List Discounts",
                Description = "Provides listings of discounts",
                Direction = MetadataRetrievalNodeDirections.Outbound,
                IsOperation = true
            };

            return new MetadataRetrievalNode[] { discountNode };
        }
    }
}
