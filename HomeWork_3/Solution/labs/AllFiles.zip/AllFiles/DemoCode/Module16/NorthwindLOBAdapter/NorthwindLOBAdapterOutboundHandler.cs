/// -----------------------------------------------------------------------------------------------------------
/// Module      :  NorthwindLOBAdapterOutboundHandler.cs
/// Description :  This class is used for sending data to the target system
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;
using System.ServiceModel;
using System.Xml.Linq;
using System.Linq;
using System.Xml;
using System.IO;

#endregion

namespace Northwind.LOB
{
    public class NorthwindLOBAdapterOutboundHandler : NorthwindLOBAdapterHandlerBase, IOutboundHandler
    {
        /// <summary>
        /// Initializes a new instance of the NorthwindLOBAdapterOutboundHandler class
        /// </summary>
        public NorthwindLOBAdapterOutboundHandler(NorthwindLOBAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IOutboundHandler Members

        /// <summary>
        /// Executes the request message on the target system and returns a response message.
        /// If there isn�t a response, this method should return null
        /// </summary>
        public Message Execute(Message message, TimeSpan timeout)
        {
            switch (message.Headers.Action)
            {
                case "getDiscounts":
                    return CreateDiscountListMessage(message.Version, message.Headers.Action);
                case "getSurcharges":
                    return CreateSurchargeListMessage(message.Version, message.Headers.Action);
                default:
                    return Message.CreateMessage(
                        message.Version,
                        MessageFault.CreateFault(FaultCode.CreateSenderFaultCode("InvalidRequest", "urn:Northwind"), new FaultReason("No such operation")),
                    message.Headers.Action + "/response");
            }
        }

        private Message CreateSurchargeListMessage(MessageVersion messageVersion, string action)
        {
            var uri = Connection.ConnectionFactory.Uri as NorthwindLOBAdapterConnectionUri;
            string surchargeFile = System.IO.Path.Combine(uri.DataDirectory, "Surcharges.xml");

            XElement root = XElement.Load(surchargeFile);
            var surcharges = from i in root.Elements("surcharge")
                              select i.Value;

            var replyMessage = Message.CreateMessage(messageVersion,
                action + "/response", surcharges.ToArray());

            return replyMessage;

        }

        private Message CreateDiscountListMessage(MessageVersion messageVersion, string action)
        {
            var uri = Connection.ConnectionFactory.Uri as NorthwindLOBAdapterConnectionUri;
            string discountFile = System.IO.Path.Combine(uri.DataDirectory, "Discounts.xml");

            XElement root = XElement.Load(discountFile);
            var surcharges = from i in root.Elements("discount")
                              select i.Value;
            StringBuilder sb = new StringBuilder();
            XmlWriter writer = XmlWriter.Create(sb);
            writer.WriteStartElement("GetDiscountsResponse", "urn:Northwind");
            foreach (var item in surcharges)
            {
                writer.WriteElementString("string", item);
            }
            writer.WriteEndElement();
            writer.Flush();

            XmlReader reader = XmlReader.Create(new StringReader(sb.ToString()));


            var replyMessage = Message.CreateMessage(messageVersion,
                action + "/response", reader);

            return replyMessage;
        }

       
        #endregion IOutboundHandler Members
    }
}
