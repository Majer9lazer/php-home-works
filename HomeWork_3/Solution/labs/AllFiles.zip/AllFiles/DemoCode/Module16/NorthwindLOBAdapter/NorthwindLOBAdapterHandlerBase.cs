/// -----------------------------------------------------------------------------------------------------------
/// Module      :  NorthwindLOBAdapterHandlerBase.cs
/// Description :  This is the base class for handlers used to store common properties/helper functions
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace Northwind.LOB
{
    public abstract class NorthwindLOBAdapterHandlerBase
    {
        #region Private Fields

        private NorthwindLOBAdapterConnection connection;
        private MetadataLookup metadataLookup;

        #endregion Private Fields

        protected NorthwindLOBAdapterHandlerBase(NorthwindLOBAdapterConnection connection
            , MetadataLookup metadataLookup)
        {
            this.connection = connection;
            this.metadataLookup = metadataLookup;
        }

        #region Public Properties

        public NorthwindLOBAdapterConnection Connection
        {
            get
            {
                return this.connection;
            }
        }

        public MetadataLookup MetadataLookup
        {
            get
            {
                return this.metadataLookup;
            }
        }

        #endregion Public Properties

        #region IDisposable

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion IDisposable

        protected virtual void Dispose(bool disposing)
        {
            //
            //TODO: Implement Dispose. Override this method in respective Handler classes
            //
           // throw new NotImplementedException("The method or operation is not implemented.");
        }
    }
}

