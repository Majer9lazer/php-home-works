/// -----------------------------------------------------------------------------------------------------------
/// Module      :  NorthwindLOBAdapterBindingElement.cs
/// Description :  Provides a base class for the configuration elements.
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Configuration;
using System.ServiceModel.Channels;
using System.Configuration;
using System.Globalization;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace Northwind.LOB
{
    public class NorthwindLOBAdapterBindingElement : StandardBindingElement
    {
        private ConfigurationPropertyCollection properties;

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the NorthwindLOBAdapterBindingElement class
        /// </summary>
        public NorthwindLOBAdapterBindingElement()
            : base(null)
        {
        }


        /// <summary>
        /// Initializes a new instance of the NorthwindLOBAdapterBindingElement class with a configuration name
        /// </summary>
        public NorthwindLOBAdapterBindingElement(string configurationName)
            : base(configurationName)
        {
        }

        #endregion Constructors

        #region Custom Generated Properties

        [System.Configuration.ConfigurationProperty("cacheDurationMinutes", DefaultValue = 60)]
        public int CacheDurationMinutes
        {
            get
            {
                return ((int)(base["CacheDurationMinutes"]));
            }
            set
            {
                base["CacheDurationMinutes"] = value;
            }
        }

        #endregion Custom Generated Properties

        #region Protected Properties

        /// <summary>
        /// Gets the type of the BindingElement
        /// </summary>
        protected override Type BindingElementType
        {
            get
            {
                return typeof(NorthwindLOBAdapterBinding);
            }
        }

        #endregion Protected Properties

        #region StandardBindingElement Members

        /// <summary>
        /// Initializes the binding with the configuration properties
        /// </summary>
        protected override void InitializeFrom(Binding binding)
        {
            base.InitializeFrom(binding);
            NorthwindLOBAdapterBinding adapterBinding = (NorthwindLOBAdapterBinding)binding;
            this["CacheDurationMinutes"] = adapterBinding.CacheDurationMinutes;
        }

        /// <summary>
        /// Applies the configuration
        /// </summary>
        protected override void OnApplyConfiguration(Binding binding)
        {
            if (binding == null)
                throw new ArgumentNullException("binding");

            NorthwindLOBAdapterBinding adapterBinding = (NorthwindLOBAdapterBinding)binding;
            adapterBinding.CacheDurationMinutes = (System.Int32)this["CacheDurationMinutes"];
        }

        /// <summary>
        /// Returns a collection of the configuration properties
        /// </summary>
        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                if (this.properties == null)
                {
                    ConfigurationPropertyCollection configProperties = base.Properties;
                    configProperties.Add(new ConfigurationProperty("CacheDurationMinutes", typeof(System.Int32), (System.Int32)60, null, null, ConfigurationPropertyOptions.None));
                    this.properties = configProperties;
                }
                return this.properties;
            }
        }


        #endregion StandardBindingElement Members
    }
}
