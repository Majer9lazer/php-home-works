/// -----------------------------------------------------------------------------------------------------------
/// Module      :  NorthwindLOBAdapterAsyncOutboundHandler.cs
/// Description :  This class implements an interface for asynchronously sending data.
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;
using System.Xml.Linq;
using System.Linq;
using System.ServiceModel;
using System.Xml;
using System.IO;

#endregion

namespace Northwind.LOB
{
    public class NorthwindLOBAdapterAsyncOutboundHandler : NorthwindLOBAdapterHandlerBase, IAsyncOutboundHandler
    {
        /// <summary>
        /// Initializes a new instance of the NorthwindLOBAdapterAsyncOutboundHandler class
        /// </summary>
        public NorthwindLOBAdapterAsyncOutboundHandler(NorthwindLOBAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IAsyncOutboundHandler Members

        /// <summary>
        /// Sends the request message to the target system
        /// </summary>
        public Message Execute(Message message, TimeSpan timeout)
        {
            switch (message.Headers.Action)
            {
                case "getDiscounts":
                    return CreateDiscountListMessage(message.Version, message.Headers.Action);
                case "getSurcharges":
                    return CreateSurchargeListMessage(message.Version, message.Headers.Action);
                default:
                    return Message.CreateMessage(
                        message.Version,
                        MessageFault.CreateFault(FaultCode.CreateSenderFaultCode("InvalidRequest", "urn:Northwind"), new FaultReason("No such operation")),
                    message.Headers.Action + "/response");
            }
        }

        private Message CreateSurchargeListMessage(MessageVersion messageVersion, string action)
        {
            var uri = Connection.ConnectionFactory.Uri as NorthwindLOBAdapterConnectionUri;
            string surchargeFile = System.IO.Path.Combine(uri.DataDirectory, "Surcharges.xml");

            XElement root = XElement.Load(surchargeFile);
            var surcharges = from i in root.Elements("surcharge")
                              select i.Value;

            StringBuilder sb = new StringBuilder();
            XmlWriter writer = XmlWriter.Create(sb,
                new XmlWriterSettings { OmitXmlDeclaration = true, Indent = true });
            writer.WriteStartElement("GetSurchargesResponse", "urn:Northwind");
            writer.WriteStartElement("GetSurchargesResult");
            foreach (var item in surcharges)
            {
                writer.WriteElementString("string", "http://schemas.microsoft.com/2003/10/Serialization/Arrays", item);
            }

            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Flush();

            XmlReader reader = XmlReader.Create(new StringReader(sb.ToString()));


            var replyMessage = Message.CreateMessage(messageVersion,
                action + "/response", reader);

            return replyMessage;

        }

        private Message CreateDiscountListMessage(MessageVersion messageVersion, string action)
        {
            var uri = Connection.ConnectionFactory.Uri as NorthwindLOBAdapterConnectionUri;
            string discountFile = System.IO.Path.Combine(uri.DataDirectory, "Discounts.xml");

            XElement root = XElement.Load(discountFile);
            var discounts = from i in root.Elements("discount")
                              select i.Value;
            StringBuilder sb = new StringBuilder();
            XmlWriter writer = XmlWriter.Create(sb,
                new XmlWriterSettings { OmitXmlDeclaration = true, Indent = true });
            writer.WriteStartElement("GetDiscountsResponse", "urn:Northwind");
            writer.WriteStartElement("GetDiscountsResult");
            foreach (var item in discounts)
            {
                writer.WriteElementString("string", "http://schemas.microsoft.com/2003/10/Serialization/Arrays", item);
            }

            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Flush();

            XmlReader reader = XmlReader.Create(new StringReader(sb.ToString()));


            var replyMessage = Message.CreateMessage(messageVersion,
                action + "/response", reader);

            return replyMessage;
        }



        /// <summary>
        /// Asynchronously sends the request message to the target system
        /// </summary>
        public IAsyncResult BeginExecute(Message message, TimeSpan timeout, AsyncCallback callback, object state)
        {
            //
            //TODO: Implement BeginExecute
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        /// <summary>
        /// Ends the asynchronous send operation
        /// </summary>
        public Message EndExecute(IAsyncResult result)
        {
            //
            //TODO: Implement EndExecute
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        #endregion IAsyncOutboundHandler Members
    }
}
