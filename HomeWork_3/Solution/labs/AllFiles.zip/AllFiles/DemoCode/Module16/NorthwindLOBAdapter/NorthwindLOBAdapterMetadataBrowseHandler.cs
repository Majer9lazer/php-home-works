/// -----------------------------------------------------------------------------------------------------------
/// Module      :  NorthwindLOBAdapterMetadataBrowseHandler.cs
/// Description :  This class is used while performing a connection-based browse for metadata from the target system.
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace Northwind.LOB
{
    public class NorthwindLOBAdapterMetadataBrowseHandler : NorthwindLOBAdapterHandlerBase, IMetadataBrowseHandler
    {
        /// <summary>
        /// Initializes a new instance of the NorthwindLOBAdapterMetadataBrowseHandler class
        /// </summary>
        public NorthwindLOBAdapterMetadataBrowseHandler(NorthwindLOBAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IMetadataBrowseHandler Members

        /// <summary>
        /// Retrieves an array of MetadataRetrievalNodes from the target system.
        /// The browse will return nodes starting from the childStartIndex in the path provided in absoluteName, and the number of nodes returned is limited by maxChildNodes.
        /// The method should complete within the specified timespan or throw a timeout exception.
        /// If absoluteName is null or an empty string, return nodes starting from the root + childStartIndex.
        /// If childStartIndex is zero, then return starting at the node indicated by absoluteName (or the root node if absoluteName is null or empty).
        /// </summary>
        public MetadataRetrievalNode[] Browse(string nodeId
            , int childStartIndex
            , int maxChildNodes, TimeSpan timeout)
        {

            if (String.IsNullOrEmpty(nodeId) || nodeId == "/")
            {
                MetadataRetrievalNode discountNode = new MetadataRetrievalNode
                {
                    NodeId = "discounts",
                    DisplayName = "Discount listings",
                    Description = "Provides listings of current discount codes",
                    Direction = MetadataRetrievalNodeDirections.Outbound,
                    IsOperation = false
                };

                MetadataRetrievalNode surchargeNode = new MetadataRetrievalNode
                {
                    NodeId = "surcharges",
                    DisplayName = "Surcharge listings",
                    Description = "Provides listings of current surcharge codes",
                    Direction = MetadataRetrievalNodeDirections.Outbound,
                    IsOperation = false
                };
                return new MetadataRetrievalNode[] { discountNode, surchargeNode };
            }
            else
            {
                switch (nodeId)
                {
                    case "discounts":
                        return GetDiscountNodes();
                    case "surcharges":
                        return GetSurchargeNodes();
                    default:
                        return new MetadataRetrievalNode[] { };
                }
            }
            
        }

        private MetadataRetrievalNode[] GetSurchargeNodes()
        {
            MetadataRetrievalNode surchargeNode = new MetadataRetrievalNode
            {
                NodeId = "getSurcharges",
                DisplayName = "List Surcharges",
                Description = "Provides listings of surcharges",
                Direction = MetadataRetrievalNodeDirections.Outbound,
                IsOperation = true
            };

            return new MetadataRetrievalNode[] { surchargeNode };
        }

        private MetadataRetrievalNode[] GetDiscountNodes()
        {
            MetadataRetrievalNode discountNode = new MetadataRetrievalNode
            {
                NodeId = "getDiscounts",
                DisplayName = "List Discounts",
                Description = "Provides listings of discounts",
                Direction = MetadataRetrievalNodeDirections.Outbound,
                IsOperation = true
            };

            return new MetadataRetrievalNode[] { discountNode };
        }

        #endregion IMetadataBrowseHandler Members
    }
}
