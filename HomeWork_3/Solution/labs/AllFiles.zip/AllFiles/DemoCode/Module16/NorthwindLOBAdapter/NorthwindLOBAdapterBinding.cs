/// -----------------------------------------------------------------------------------------------------------
/// Module      :  NorthwindLOBAdapterBinding.cs
/// Description :  This is the class used while creating a binding for an adapter
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace Northwind.LOB
{
    public class NorthwindLOBAdapterBinding : AdapterBinding
    {
        // Scheme in Binding does not have to be the same as Adapter Scheme. 
        // Over write this value as appropriate.
        private const string BindingScheme = "PS";

        /// <summary>
        /// Initializes a new instance of the AdapterBinding class
        /// </summary>
        public NorthwindLOBAdapterBinding() { }

        /// <summary>
        /// Initializes a new instance of the AdapterBinding class with a configuration name
        /// </summary>
        public NorthwindLOBAdapterBinding(string configName)
        {
            ApplyConfiguration(configName);
        }

        /// <summary>
        /// Applies the current configuration to the NorthwindLOBAdapterBindingCollectionElement
        /// </summary>
        private void ApplyConfiguration(string configurationName)
        {
            /*
            //
            // TODO : replace the <The config name of your adapter> below with the configuration name of your adapter
            //
            BindingsSection bindingsSection = (BindingsSection)System.Configuration.ConfigurationManager.GetSection("system.serviceModel/bindings");
            NorthwindLOBAdapterBindingCollectionElement bindingCollectionElement = (NorthwindLOBAdapterBindingCollectionElement)bindingsSection["<The config name of your adapter>"];
            NorthwindLOBAdapterBindingElement element = bindingCollectionElement.Bindings[configurationName];
            if (element != null)
            {
                element.ApplyConfiguration(this);
            }
            */
            throw new NotImplementedException("The method or operation is not implemented.");
        }



        #region Private Fields

        private NorthwindLOBAdapter binding;

        #endregion Private Fields

        #region Custom Generated Fields

        private int cacheDurationMinutes;

        #endregion Custom Generated Fields

        #region Public Properties

        /// <summary>
        /// Gets the URI transport scheme that is used by the channel and listener factories that are built by the bindings.
        /// </summary>
        public override string Scheme
        {
            get
            {
                return BindingScheme;
            }
        }

        /// <summary>
        /// Returns a value indicating whether this binding supports metadata browsing.
        /// </summary>
        public override bool SupportsMetadataBrowse
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Returns a value indicating whether this binding supports metadata retrieval.
        /// </summary>
        public override bool SupportsMetadataGet
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Returns a value indicating whether this binding supports metadata searching.
        /// </summary>
        public override bool SupportsMetadataSearch
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Returns the custom type of the ConnectionUri.
        /// </summary>
        public override Type ConnectionUriType
        {
            get
            {
                return typeof(NorthwindLOBAdapterConnectionUri);
            }
        }

        #endregion Public Properties

        #region Custom Generated Properties

        [System.Configuration.ConfigurationProperty("cacheDurationMinutes", DefaultValue = 60)]
        public int CacheDurationMinutes
        {
            get
            {
                return this.cacheDurationMinutes;
            }
            set
            {
                this.cacheDurationMinutes = value;
            }
        }

        #endregion Custom Generated Properties

        #region Private Properties

        private NorthwindLOBAdapter BindingElement
        {
            get
            {
                if (binding == null)
                    binding = new NorthwindLOBAdapter();
                binding.CacheDurationMinutes = this.CacheDurationMinutes;
                return binding;
            }
        }

        #endregion Private Properties

        #region Public Methods

        /// <summary>
        /// Creates a clone of the existing BindingElement and returns it
        /// </summary>
        public override BindingElementCollection CreateBindingElements()
        {
            BindingElementCollection bindingElements = new BindingElementCollection();
            //Only create once
            bindingElements.Add(this.BindingElement);
            //Return the clone
            return bindingElements.Clone();
        }

        #endregion Public Methods

    }
}
