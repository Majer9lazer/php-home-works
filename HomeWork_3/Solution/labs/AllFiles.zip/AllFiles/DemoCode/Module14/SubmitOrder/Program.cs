﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;

namespace InboundClient
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2) { PrintUsage(); return; }

            string fileName = args[0];
            string url      = args[1];

            MessageVersion mv = MessageVersion.Default;

            Binding binding = new NetTcpBinding();

            Message msg = Message.CreateMessage(mv, "*", XmlReader.Create(fileName));

            IUniversalTwoWayContract proxy =
                    new ChannelFactory<IUniversalTwoWayContract>(binding, url).CreateChannel();

            Message response = proxy.SubmitMessage(msg);

            Console.WriteLine("Message was submitted.  Response:\n\n{0}", response.ToString());
        }

        private static void PrintUsage()
        {
            Console.WriteLine("Usage: SubmitOrder.exe <Message File Name> <url>");
            Console.ReadLine();
        }
    }

    [ServiceContract]
    public interface IUniversalTwoWayContract
    {
        [OperationContract(Action = "*",ReplyAction="*")]
        Message SubmitMessage(Message inmsg);
    }
}
