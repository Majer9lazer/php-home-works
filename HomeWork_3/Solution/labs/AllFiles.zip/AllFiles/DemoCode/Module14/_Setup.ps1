. ..\scripts\Functions.ps1

Get-ScriptDirectory | set-location

RemoveBTSApplication Demos.Northwind

CreateBTSApplication Demos.Northwind

ImportBTSBindingFile .\Northwind\Demos.Northwind.Bindings.1.xml Demos.Northwind


