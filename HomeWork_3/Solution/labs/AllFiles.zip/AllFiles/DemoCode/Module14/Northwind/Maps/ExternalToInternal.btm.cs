namespace Demos.Northwind.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.OrderExternal", typeof(global::Demos.Northwind.Schemas.OrderExternal))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.OrderInternal", typeof(global::Demos.Northwind.Schemas.OrderInternal))]
    public sealed class ExternalToInternal : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp ScriptNS0"" version=""1.0"" xmlns:s0=""http://demos.northwind.com/fbts/order/external"" xmlns:common=""http://demos.northwind.com/fbts/common"" xmlns:ns0=""http://demos.northwind.com/fbts/order/internal"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:OrderExternal"" />
  </xsl:template>
  <xsl:template match=""/s0:OrderExternal"">
    <xsl:variable name=""var:v1"" select=""userCSharp:DateCurrentDateTime()"" />
    <xsl:variable name=""var:v4"" select=""string(CustomerID/text())"" />
    <ns0:Order>
      <OrderDate>
        <xsl:value-of select=""$var:v1"" />
      </OrderDate>
      <CustomerID>
        <xsl:value-of select=""CustomerID/text()"" />
      </CustomerID>
      <xsl:variable name=""var:v2"" select=""ScriptNS0:DBLookup(0 , string(CustomerID/text()) , &quot;Provider=SQLOLEDB;Data Source=.;Initial Catalog=Northwind;Integrated Security=SSPI&quot; , &quot;Customers&quot; , &quot;CustomerID&quot;)"" />
      <xsl:variable name=""var:v3"" select=""ScriptNS0:DBValueExtract(string($var:v2) , &quot;CompanyName&quot;)"" />
      <CompanyName>
        <xsl:value-of select=""$var:v3"" />
      </CompanyName>
      <PointOfContact>
        <xsl:variable name=""var:v5"" select=""ScriptNS0:DBLookup(0 , $var:v4 , &quot;Provider=SQLOLEDB;Data Source=.;Initial Catalog=Northwind;Integrated Security=SSPI&quot; , &quot;Customers&quot; , &quot;CustomerID&quot;)"" />
        <xsl:variable name=""var:v6"" select=""ScriptNS0:DBValueExtract(string($var:v5) , &quot;ContactName&quot;)"" />
        <Name>
          <xsl:value-of select=""$var:v6"" />
        </Name>
        <xsl:variable name=""var:v7"" select=""ScriptNS0:DBLookup(0 , $var:v4 , &quot;Provider=SQLOLEDB;Data Source=.;Initial Catalog=Northwind;Integrated Security=SSPI&quot; , &quot;Customers&quot; , &quot;CustomerID&quot;)"" />
        <xsl:variable name=""var:v8"" select=""ScriptNS0:DBValueExtract(string($var:v7) , &quot;ContactTitle&quot;)"" />
        <Title>
          <xsl:value-of select=""$var:v8"" />
        </Title>
        <xsl:variable name=""var:v9"" select=""ScriptNS0:DBLookup(0 , $var:v4 , &quot;Provider=SQLOLEDB;Data Source=.;Initial Catalog=Northwind;Integrated Security=SSPI&quot; , &quot;Customers&quot; , &quot;CustomerID&quot;)"" />
        <xsl:variable name=""var:v10"" select=""ScriptNS0:DBValueExtract(string($var:v9) , &quot;Phone&quot;)"" />
        <Phone>
          <xsl:value-of select=""$var:v10"" />
        </Phone>
      </PointOfContact>
      <xsl:for-each select=""Addresses/Address"">
        <xsl:variable name=""var:v11"" select=""userCSharp:LogicalEq(string(@Label) , &quot;ShipTo&quot;)"" />
        <xsl:if test=""$var:v11"">
          <common:ShipTo>
            <Addressee>
              <xsl:value-of select=""Addressee/text()"" />
            </Addressee>
            <Line1>
              <xsl:value-of select=""Line1/text()"" />
            </Line1>
            <Line2>
              <xsl:value-of select=""Line2/text()"" />
            </Line2>
            <City>
              <xsl:value-of select=""City/text()"" />
            </City>
            <Region>
              <xsl:value-of select=""Region/text()"" />
            </Region>
            <PostalCode>
              <xsl:value-of select=""PostalCode/text()"" />
            </PostalCode>
            <Country>
              <xsl:value-of select=""Country/text()"" />
            </Country>
          </common:ShipTo>
        </xsl:if>
      </xsl:for-each>
      <xsl:for-each select=""Addresses/Address"">
        <xsl:variable name=""var:v12"" select=""string(@Label)"" />
        <xsl:variable name=""var:v13"" select=""userCSharp:LogicalEq($var:v12 , &quot;BillTo&quot;)"" />
        <xsl:if test=""$var:v13"">
          <common:BillTo>
            <Addressee>
              <xsl:value-of select=""Addressee/text()"" />
            </Addressee>
            <Line1>
              <xsl:value-of select=""Line1/text()"" />
            </Line1>
            <Line2>
              <xsl:value-of select=""Line2/text()"" />
            </Line2>
            <City>
              <xsl:value-of select=""City/text()"" />
            </City>
            <Region>
              <xsl:value-of select=""Region/text()"" />
            </Region>
            <PostalCode>
              <xsl:value-of select=""PostalCode/text()"" />
            </PostalCode>
            <Country>
              <xsl:value-of select=""Country/text()"" />
            </Country>
          </common:BillTo>
        </xsl:if>
      </xsl:for-each>
      <LineItems>
        <xsl:for-each select=""Items/Item"">
          <xsl:variable name=""var:v14"" select=""userCSharp:MathMultiply(string(Price/text()) , string(Quantity/text()))"" />
          <common:LineItem>
            <ProductID>
              <xsl:value-of select=""Sku/text()"" />
            </ProductID>
            <ProductName>
              <xsl:value-of select=""Description/text()"" />
            </ProductName>
            <UnitPrice>
              <xsl:value-of select=""Price/text()"" />
            </UnitPrice>
            <Quantity>
              <xsl:value-of select=""Quantity/text()"" />
            </Quantity>
            <ExtendedPrice>
              <xsl:value-of select=""$var:v14"" />
            </ExtendedPrice>
          </common:LineItem>
        </xsl:for-each>
      </LineItems>
      <xsl:variable name=""var:v15"" select=""userCSharp:InitCumulativeSum(0)"" />
      <xsl:for-each select=""/s0:OrderExternal/Items/Item"">
        <xsl:variable name=""var:v16"" select=""string(Price/text())"" />
        <xsl:variable name=""var:v17"" select=""string(Quantity/text())"" />
        <xsl:variable name=""var:v18"" select=""userCSharp:MathMultiply($var:v16 , $var:v17)"" />
        <xsl:variable name=""var:v19"" select=""userCSharp:AddToCumulativeSum(0,string($var:v18),&quot;1000&quot;)"" />
      </xsl:for-each>
      <xsl:variable name=""var:v20"" select=""userCSharp:GetCumulativeSum(0)"" />
      <OrderTotal>
        <xsl:value-of select=""$var:v20"" />
      </OrderTotal>
    </ns0:Order>
    <xsl:variable name=""var:v21"" select=""ScriptNS0:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string MathMultiply(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 1;
	bool first = true;
	foreach (string obj in listValues)
	{
		double d = 0;
		if (IsNumeric(obj, ref d))
		{
			if (first)
			{
				first = false;
				ret = d;
			}
			else
			{
				ret *= d;
			}
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public string InitCumulativeSum(int index)
{
	if (index >= 0)
	{
		if (index >= myCumulativeSumArray.Count)
		{
			int i = myCumulativeSumArray.Count;
			for (; i<=index; i++)
			{
				myCumulativeSumArray.Add("""");
			}
		}
		else
		{
			myCumulativeSumArray[index] = """";
		}
	}
	return """";
}

public System.Collections.ArrayList myCumulativeSumArray = new System.Collections.ArrayList();

public string AddToCumulativeSum(int index, string val, string notused)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
    }
	double d = 0;
	if (IsNumeric(val, ref d))
	{
		if (myCumulativeSumArray[index] == """")
		{
			myCumulativeSumArray[index] = d;
		}
		else
		{
			myCumulativeSumArray[index] = (double)(myCumulativeSumArray[index]) + d;
		}
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string GetCumulativeSum(int index)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string DateCurrentDateTime()
{
	DateTime dt = DateTime.Now;
	string curdate = dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
	string curtime = dt.ToString(""T"", System.Globalization.CultureInfo.InvariantCulture);
	string retval = curdate + ""T"" + curtime;
	return retval;
}


public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Demos.Northwind.Schemas.OrderExternal";
        
        private const global::Demos.Northwind.Schemas.OrderExternal _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Demos.Northwind.Schemas.OrderInternal";
        
        private const global::Demos.Northwind.Schemas.OrderInternal _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Demos.Northwind.Schemas.OrderExternal";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Demos.Northwind.Schemas.OrderInternal";
                return _TrgSchemas;
            }
        }
    }
}
