namespace Demos.Northwind.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.OrderInternal", typeof(global::Demos.Northwind.Schemas.OrderInternal))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Demos.Northwind.Schemas.OrderBilling", typeof(global::Demos.Northwind.Schemas.OrderBilling))]
    public sealed class OrderToBilling : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s1 s0"" version=""1.0"" xmlns:ns0=""http://demos.northwind.com/fbts/billing"" xmlns:s0=""http://demos.northwind.com/fbts/common"" xmlns:s1=""http://demos.northwind.com/fbts/order/internal"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s1:Order"" />
  </xsl:template>
  <xsl:template match=""/s1:Order"">
    <ns0:OrderBilling>
      <ns0:CustomerID>
        <xsl:value-of select=""CustomerID/text()"" />
      </ns0:CustomerID>
      <xsl:call-template name=""TranslateDate"">
        <xsl:with-param name=""param1"" select=""string(OrderDate/text())"" />
      </xsl:call-template>
      <ns0:OrderTotal>
        <xsl:value-of select=""OrderTotal/text()"" />
      </ns0:OrderTotal>
      <ns0:BillTo>
        <ns0:Addressee>
          <xsl:value-of select=""s0:BillTo/Addressee/text()"" />
        </ns0:Addressee>
        <ns0:Line1>
          <xsl:value-of select=""s0:BillTo/Line1/text()"" />
        </ns0:Line1>
        <ns0:Line2>
          <xsl:value-of select=""s0:BillTo/Line2/text()"" />
        </ns0:Line2>
        <ns0:City>
          <xsl:value-of select=""s0:BillTo/City/text()"" />
        </ns0:City>
        <ns0:Region>
          <xsl:value-of select=""s0:BillTo/Region/text()"" />
        </ns0:Region>
        <ns0:PostalCode>
          <xsl:value-of select=""s0:BillTo/PostalCode/text()"" />
        </ns0:PostalCode>
        <ns0:Country>
          <xsl:value-of select=""s0:BillTo/Country/text()"" />
        </ns0:Country>
        <xsl:value-of select=""s0:BillTo/text()"" />
      </ns0:BillTo>
    </ns0:OrderBilling>
  </xsl:template>
  <xsl:template name=""TranslateDate"">
   <xsl:param name=""param1"" />
   <OrderDate><xsl:value-of select=""translate(substring-before($param1,'T'), '-', '/')"" /></OrderDate>
</xsl:template>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Demos.Northwind.Schemas.OrderInternal";
        
        private const global::Demos.Northwind.Schemas.OrderInternal _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Demos.Northwind.Schemas.OrderBilling";
        
        private const global::Demos.Northwind.Schemas.OrderBilling _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Demos.Northwind.Schemas.OrderInternal";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Demos.Northwind.Schemas.OrderBilling";
                return _TrgSchemas;
            }
        }
    }
}
