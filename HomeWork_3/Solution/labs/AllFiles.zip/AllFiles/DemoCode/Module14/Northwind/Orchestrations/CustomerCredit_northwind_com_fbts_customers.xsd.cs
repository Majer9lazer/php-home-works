namespace Demos.Northwind.Orchestrations {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [global::System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.BizTalk.Schema.Compiler", "3.0.1.0")]
    [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
    [global::System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [SchemaType(SchemaTypeEnum.Document)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"GetCustomerRating", @"GetCustomerRatingResponse", @"CustomerRating"})]
    public sealed class CustomerCredit_northwind_com_fbts_customers : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns:tns=""http://northwind.com/fbts/customers"" elementFormDefault=""qualified"" targetNamespace=""http://northwind.com/fbts/customers"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""GetCustomerRating"">
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" name=""customerID"" nillable=""true"" type=""xs:string"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:element name=""GetCustomerRatingResponse"">
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" name=""GetCustomerRatingResult"" nillable=""true"" type=""tns:CustomerRating"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:complexType name=""CustomerRating"">
    <xs:sequence>
      <xs:element minOccurs=""0"" name=""CreditLimit"" type=""xs:double"" />
      <xs:element minOccurs=""0"" name=""CustomerID"" nillable=""true"" type=""xs:string"" />
      <xs:element minOccurs=""0"" name=""Rating"" type=""xs:double"" />
    </xs:sequence>
  </xs:complexType>
  <xs:element name=""CustomerRating"" nillable=""true"" type=""tns:CustomerRating"" />
</xs:schema>";
        
        public CustomerCredit_northwind_com_fbts_customers() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [3];
                _RootElements[0] = "GetCustomerRating";
                _RootElements[1] = "GetCustomerRatingResponse";
                _RootElements[2] = "CustomerRating";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
        
        [Schema(@"http://northwind.com/fbts/customers",@"GetCustomerRating")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"GetCustomerRating"})]
        public sealed class GetCustomerRating : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public GetCustomerRating() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "GetCustomerRating";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://northwind.com/fbts/customers",@"GetCustomerRatingResponse")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"GetCustomerRatingResponse"})]
        public sealed class GetCustomerRatingResponse : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public GetCustomerRatingResponse() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "GetCustomerRatingResponse";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://northwind.com/fbts/customers",@"CustomerRating")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"CustomerRating"})]
        public sealed class CustomerRating : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public CustomerRating() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "CustomerRating";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
    }
}
